
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 5000;

// ============================================================
// ROUTES
// ============================================================

const healthRoutes = require("./routes/health");
const campusRoutes = require("./routes/campus");
const buildingsRoutes = require("./routes/buildings");
const classroomsRoutes = require("./routes/classrooms");
const foodRoutes = require("./routes/food");
const libraryRoutes = require("./routes/library");
const eventsRoutes = require("./routes/events");
const announcementsRoutes = require("./routes/announcements");
const departmentsRoutes = require("./routes/departments");
const emergencyRoutes = require("./routes/emergency");
const searchRoutes = require("./routes/search");
const aiRoutes = require("./routes/ai");
const complaintsRoutes = require("./routes/complaints");
const statsRoutes = require("./routes/stats");

// 🔐 Authentication Routes
const authRoutes = require("./routes/auth");

// ============================================================
// MIDDLEWARE
// ============================================================

app.use(cors());
app.use(express.json());

// ============================================================
// API ROUTES
// ============================================================

app.use("/api/health", healthRoutes);
app.use("/api/campus", campusRoutes);
app.use("/api/buildings", buildingsRoutes);
app.use("/api/classrooms", classroomsRoutes);
app.use("/api/food", foodRoutes);
app.use("/api/library", libraryRoutes);
app.use("/api/events", eventsRoutes);
app.use("/api/announcements", announcementsRoutes);
app.use("/api/departments", departmentsRoutes);
app.use("/api/emergency", emergencyRoutes);
app.use("/api/search", searchRoutes);
app.use("/api/ai", aiRoutes);
app.use("/api/complaints", complaintsRoutes);
app.use("/api/stats", statsRoutes);

// 🔐 Login / Signup APIs
app.use("/api/auth", authRoutes);

// ============================================================
// ROOT ROUTE
// ============================================================

app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "Campus Helper AI Backend is running 🚀",
        version: "1.0.0"
    });
});

// ============================================================
// 404 HANDLER
// ============================================================

app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: "API endpoint not found",
        path: req.originalUrl
    });
});

// ============================================================
// ERROR HANDLER
// ============================================================

app.use((err, req, res, next) => {
    console.error("Server Error:", err);

    res.status(500).json({
        success: false,
        message: "Internal server error"
    });
});

// ============================================================
// START SERVER
// ============================================================

app.listen(PORT, () => {
    console.log("======================================");
    console.log("       CAMPUS HELPER AI BACKEND");
    console.log("======================================");
    console.log(`Server: http://localhost:${PORT}`);
    console.log(
        `Health: http://localhost:${PORT}/api/health`
    );
    console.log(
        `Login: http://localhost:${PORT}/api/auth/login`
    );
    console.log(
        `Signup: http://localhost:${PORT}/api/auth/signup`
    );
    console.log("======================================");
});

