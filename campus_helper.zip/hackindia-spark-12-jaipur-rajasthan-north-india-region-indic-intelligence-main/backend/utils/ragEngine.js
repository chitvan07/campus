const { getData } = require("./data");

// ============================================================
// TEXT NORMALIZATION
// ============================================================

function normalizeText(text) {
    return String(text || "")
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}

// ============================================================
// TOKENIZE
// ============================================================

function tokenize(text) {
    return normalizeText(text)
        .split(/\s+/)
        .filter(word => word.length > 1);
}

// ============================================================
// CREATE SEARCHABLE TEXT
// ============================================================

function objectToText(obj) {
    if (!obj || typeof obj !== "object") {
        return String(obj || "");
    }

    let text = "";

    Object.entries(obj).forEach(([key, value]) => {
        if (value === null || value === undefined) return;

        if (typeof value === "object") {
            text += ` ${objectToText(value)}`;
        } else {
            text += ` ${key} ${value}`;
        }
    });

    return text;
}

// ============================================================
// CATEGORY DOCUMENTS
// ============================================================

function createDocuments(data) {
    const documents = [];

    const categories = [
        "buildings",
        "classrooms",
        "food",
        "events",
        "announcements",
        "departments",
        "emergency"
    ];

    // --------------------------------------------------------
    // CAMPUS
    // --------------------------------------------------------

    if (data.campus) {
        documents.push({
            category: "campus",
            title: data.campus.name || "Campus",
            content: objectToText(data.campus),
            item: data.campus
        });
    }

    // --------------------------------------------------------
    // LIBRARY
    // --------------------------------------------------------

    if (data.library) {
        documents.push({
            category: "library",
            title: data.library.name || "Library",
            content: objectToText(data.library),
            item: data.library
        });
    }

    // --------------------------------------------------------
    // FOOD TIMINGS
    // --------------------------------------------------------

    if (data.foodTimings) {
        documents.push({
            category: "foodTimings",
            title: "Food Timings",
            content: objectToText(data.foodTimings),
            item: data.foodTimings
        });
    }

    // --------------------------------------------------------
    // OTHER CATEGORIES
    // --------------------------------------------------------

    categories.forEach(category => {
        const items = data[category] || [];

        items.forEach((item, index) => {
            documents.push({
                category,
                title:
                    item.name ||
                    item.title ||
                    item.code ||
                    item.service ||
                    item.shortName ||
                    `${category} ${index + 1}`,
                content: objectToText(item),
                item
            });
        });
    });

    return documents;
}

// ============================================================
// CATEGORY DETECTION
// ============================================================

function detectCategory(question) {
    const q = normalizeText(question);

    if (
        q.includes("library") ||
        q.includes("books") ||
        q.includes("reading") ||
        q.includes("seat")
    ) {
        return "library";
    }

    if (
        q.includes("food") ||
        q.includes("canteen") ||
        q.includes("eat") ||
        q.includes("restaurant") ||
        q.includes("mess") ||
        q.includes("breakfast") ||
        q.includes("lunch") ||
        q.includes("dinner") ||
        q.includes("snacks")
    ) {
        return "food";
    }

    if (
        q.includes("event") ||
        q.includes("hackathon") ||
        q.includes("workshop") ||
        q.includes("sports") ||
        q.includes("orientation")
    ) {
        return "events";
    }

    if (
        q.includes("announcement") ||
        q.includes("notice") ||
        q.includes("exam") ||
        q.includes("schedule")
    ) {
        return "announcements";
    }

    if (
        q.includes("department") ||
        q.includes("cse") ||
        q.includes("ece") ||
        q.includes("ai") ||
        q.includes("machine learning") ||
        q.includes("information technology")
    ) {
        return "departments";
    }

    if (
        q.includes("emergency") ||
        q.includes("security") ||
        q.includes("ambulance") ||
        q.includes("police") ||
        q.includes("medical")
    ) {
        return "emergency";
    }

    if (
        q.includes("room") ||
        q.includes("classroom") ||
        q.includes("lab") ||
        /\b[a-z]-?\d{3}\b/i.test(question)
    ) {
        return "classrooms";
    }

    if (
        q.includes("building") ||
        q.includes("block") ||
        q.includes("auditorium") ||
        q.includes("sports complex")
    ) {
        return "buildings";
    }

    return null;
}

// ============================================================
// SCORE DOCUMENT
// ============================================================

function scoreDocument(document, question) {
    const q = normalizeText(question);
    const queryTokens = tokenize(q);

    const title = normalizeText(document.title);
    const content = normalizeText(document.content);

    let score = 0;

    // Exact question match
    if (content.includes(q)) {
        score += 50;
    }

    // Title match
    if (title && q.includes(title)) {
        score += 40;
    }

    if (title && title.includes(q)) {
        score += 40;
    }

    // Token matching
    queryTokens.forEach(token => {
        if (title.includes(token)) {
            score += 15;
        }

        if (content.includes(token)) {
            score += 5;
        }
    });

    // Category boost
    const detectedCategory = detectCategory(question);

    if (
        detectedCategory &&
        document.category === detectedCategory
    ) {
        score += 30;
    }

    // Important exact patterns
    const roomPattern = /\b[a-z]-?\d{3}\b/i;

    if (
        roomPattern.test(question) &&
        roomPattern.test(document.title)
    ) {
        score += 100;
    }

    return score;
}

// ============================================================
// RETRIEVE RELEVANT DOCUMENTS
// ============================================================

function retrieve(question, limit = 5) {
    const data = getData();

    const documents = createDocuments(data);

    const scoredDocuments = documents
        .map(document => ({
            ...document,
            score: scoreDocument(document, question)
        }))
        .filter(document => document.score > 0)
        .sort((a, b) => b.score - a.score);

    return scoredDocuments.slice(0, limit);
}

// ============================================================
// BUILD RAG CONTEXT
// ============================================================

function buildContext(question, limit = 5) {
    const results = retrieve(question, limit);

    if (results.length === 0) {
        return {
            context: "",
            results: []
        };
    }

    const context = results
        .map((result, index) => {
            return `
SOURCE ${index + 1}
CATEGORY: ${result.category}
TITLE: ${result.title}
DATA:
${JSON.stringify(result.item, null, 2)}
`;
        })
        .join("\n");

    return {
        context,
        results
    };
}

// ============================================================
// EXPORT
// ============================================================

module.exports = {
    retrieve,
    buildContext,
    createDocuments,
    detectCategory
};