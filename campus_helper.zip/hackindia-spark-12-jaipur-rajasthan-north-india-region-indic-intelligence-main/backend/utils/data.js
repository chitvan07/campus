const fs = require("fs");
const path = require("path");

const dataPath = path.join(
    __dirname,
    "..",
    "data",
    "campusData.json"
);

let campusData;

try {
    campusData = JSON.parse(
        fs.readFileSync(dataPath, "utf-8")
    );

    console.log("Campus data loaded successfully.");
} catch (error) {
    console.error(
        "Error loading campusData.json:",
        error.message
    );

    campusData = {};
}

function getData() {
    return campusData;
}

module.exports = {
    getData
};