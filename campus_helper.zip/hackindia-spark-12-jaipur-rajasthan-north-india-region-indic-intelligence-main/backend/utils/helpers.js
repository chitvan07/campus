
// ============================================================
// CAMPUS HELPER - HELPER FUNCTIONS
// ============================================================

function normalizeText(value) {
    return String(value || "")
        .toLowerCase()
        .trim()
        .replace(/[?!.,]/g, " ")
        .replace(/\s+/g, " ");
}


// Extract useful search terms from a user's question
function extractSearchTerms(query) {
    const normalized = normalizeText(query);

    // Classroom / room codes
    // Examples:
    // C-204
    // c204
    // C 204
    const roomMatches =
        normalized.match(
            /\b[a-z]{1,3}\s*[-]?\s*\d{2,4}\b/gi
        ) || [];

    const roomCodes = roomMatches.map(room =>
        room
            .toLowerCase()
            .replace(/\s+/g, "")
            .replace(/([a-z]+)(\d+)/, "$1-$2")
    );

    // Remove common question words
    const stopWords = new Set([
        "where",
        "is",
        "the",
        "a",
        "an",
        "what",
        "which",
        "who",
        "when",
        "how",
        "can",
        "could",
        "please",
        "tell",
        "me",
        "about",
        "located",
        "location",
        "find",
        "show",
        "give",
        "for",
        "of",
        "in",
        "on",
        "at",
        "to",
        "does",
        "do",
        "you",
        "have",
        "there",
        "this",
        "that"
    ]);

    const words = normalized
        .split(/\s+/)
        .filter(word =>
            word.length > 1 &&
            !stopWords.has(word)
        );

    return [
        ...new Set([
            ...roomCodes,
            ...words
        ])
    ];
}


// Check whether an object contains the user's query
function objectContainsQuery(object, query) {
    const text = JSON.stringify(object)
        .toLowerCase();

    const normalizedQuery =
        normalizeText(query);

    // Exact full-query match
    if (
        normalizedQuery &&
        text.includes(normalizedQuery)
    ) {
        return true;
    }

    const searchTerms =
        extractSearchTerms(query);

    if (!searchTerms.length) {
        return false;
    }

    // Check useful terms
    return searchTerms.some(term => {
        const normalizedText =
            text
                .replace(/\s+/g, "")
                .replace(/"/g, "");

        const normalizedTerm =
            term
                .toLowerCase()
                .replace(/\s+/g, "")
                .replace(/"/g, "");

        // C-204 ↔ C204
        const withoutHyphenText =
            normalizedText.replace(/-/g, "");

        const withoutHyphenTerm =
            normalizedTerm.replace(/-/g, "");

        return (
            normalizedText.includes(normalizedTerm) ||
            withoutHyphenText.includes(
                withoutHyphenTerm
            )
        );
    });
}


// Filter an array using the smart query matcher
function filterData(data, query) {
    if (!query) {
        return data;
    }

    if (!Array.isArray(data)) {
        return [];
    }

    return data.filter(item =>
        objectContainsQuery(item, query)
    );
}


// Standard success response
function success(
    res,
    data,
    message = "Success"
) {
    return res.json({
        success: true,
        message,
        data
    });
}


// Standard error response
function error(
    res,
    message,
    status = 500
) {
    return res.status(status).json({
        success: false,
        message
    });
}


module.exports = {
    normalizeText,
    objectContainsQuery,
    filterData,
    success,
    error
};

