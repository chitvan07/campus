const { getData } = require("./data");
const {
    retrieve,
    buildContext
} = require("./ragEngine");

// ============================================================
// FORMAT RESULT
// ============================================================

function formatResult(result) {
    const item = result.item;

    if (!item || typeof item !== "object") {
        return String(item || "");
    }

    const parts = [];

    Object.entries(item).forEach(([key, value]) => {
        if (
            value === null ||
            value === undefined ||
            typeof value === "object"
        ) {
            return;
        }

        const formattedKey =
            key.charAt(0).toUpperCase() + key.slice(1);

        parts.push(`${formattedKey}: ${value}`);
    });

    return parts.join(" • ");
}

// ============================================================
// SPECIAL ANSWERS
// ============================================================

function handleSpecialQuestion(question, data) {
    const q = question.toLowerCase().trim();

    // --------------------------------------------------------
    // GREETING
    // --------------------------------------------------------

    if (
        ["hi", "hello", "hey", "hii", "helo"].includes(q)
    ) {
        return {
            answer:
                "Hello! 👋 I am Campus Helper AI. How can I help you around the campus?"
        };
    }

    // --------------------------------------------------------
    // THANK YOU
    // --------------------------------------------------------

    if (
        q.includes("thank you") ||
        q.includes("thanks") ||
        q === "thx"
    ) {
        return {
            answer:
                "You're welcome! 😊 Let me know if you need anything else."
        };
    }

    // --------------------------------------------------------
    // FOOD TIMINGS
    // --------------------------------------------------------

    if (
        q.includes("food timing") ||
        q.includes("food timings") ||
        q.includes("lunch timing") ||
        q.includes("breakfast timing") ||
        q.includes("dinner timing")
    ) {
        const timings = data.foodTimings || {};

        const answer = Object.entries(timings)
            .map(([key, value]) => `${key}: ${value}`)
            .join("\n");

        return {
            answer:
                `🍴 Campus food timings:\n\n${answer}`,
            data: timings
        };
    }

    // --------------------------------------------------------
    // LIBRARY
    // --------------------------------------------------------

    if (
        q.includes("library") &&
        (
            q.includes("open") ||
            q.includes("timing") ||
            q.includes("busy") ||
            q.includes("seat")
        )
    ) {
        const library = data.library || {};

        let answer =
            `📚 ${library.name || "Library"}\n\n`;

        if (library.timings) {
            answer += `Timings: ${library.timings}\n`;
        }

        if (library.status) {
            answer += `Status: ${library.status}\n`;
        }

        if (library.overallCapacity) {
            answer += `Capacity: ${library.overallCapacity}\n`;
        }

        if (library.floors) {
            answer += "\nFloor details:\n";

            library.floors.forEach(floor => {
                answer +=
                    `• ${floor.name}: ${floor.availableSeats}/${floor.totalSeats} seats available (${floor.status})\n`;
            });
        }

        return {
            answer,
            data: library
        };
    }

    // --------------------------------------------------------
    // CAMPUS
    // --------------------------------------------------------

    if (
        q === "campus" ||
        q === "college" ||
        q === "university" ||
        q.includes("about campus")
    ) {
        return {
            answer:
                `🏫 ${data.campus?.name || "Campus"}\n\n${data.campus?.tagline || ""}`,
            data: data.campus
        };
    }

    return null;
}

// ============================================================
// GENERATE GROUNDED ANSWER
// ============================================================

function generateAnswer(question, results, data) {
    if (!results || results.length === 0) {
        return {
            answer:
                "I couldn't find relevant information in the campus knowledge base. Try asking about a building, classroom, library, canteen, department, event, announcement or emergency service."
        };
    }

    const best = results[0];

    // --------------------------------------------------------
    // CLASSROOM
    // --------------------------------------------------------

    if (best.category === "classrooms") {
        const item = best.item;

        return {
            answer:
                `📍 I found the classroom:\n\n` +
                `Room: ${item.code || item.name || "Not available"}\n` +
                `Building: ${item.building || "Not available"}\n` +
                `Floor: ${item.floor ?? "Not available"}\n` +
                `Section: ${item.section || "Not available"}\n` +
                `Capacity: ${item.capacity || "Not available"}\n` +
                `Type: ${item.type || "Classroom"}`,
            results
        };
    }

    // --------------------------------------------------------
    // BUILDING
    // --------------------------------------------------------

    if (best.category === "buildings") {
        const item = best.item;

        return {
            answer:
                `🏢 I found the building:\n\n` +
                `Name: ${item.name || "Not available"}\n` +
                `Type: ${item.type || "Not available"}\n` +
                `Floors: ${item.floors || "Not available"}\n` +
                `Description: ${item.description || "No description available."}`,
            results
        };
    }

    // --------------------------------------------------------
    // FOOD
    // --------------------------------------------------------

    if (best.category === "food") {
        const foodResults = results.filter(
            result => result.category === "food"
        );

        const answer = foodResults
            .slice(0, 5)
            .map((result, index) => {
                return (
                    `${index + 1}. ${formatResult(result)}`
                );
            })
            .join("\n\n");

        return {
            answer:
                `🍴 I found these food options:\n\n${answer}`,
            results
        };
    }

    // --------------------------------------------------------
    // LIBRARY
    // --------------------------------------------------------

    if (best.category === "library") {
        const library = best.item;

        return {
            answer:
                `📚 ${library.name || "Central Library"}\n\n` +
                `Status: ${library.status || "Not available"}\n` +
                `Timings: ${library.timings || "Not available"}\n` +
                `Capacity: ${library.overallCapacity || "Not available"}`,
            results
        };
    }

    // --------------------------------------------------------
    // EVENTS
    // --------------------------------------------------------

    if (best.category === "events") {
        const eventResults = results.filter(
            result => result.category === "events"
        );

        const answer = eventResults
            .slice(0, 5)
            .map((result, index) => {
                const event = result.item;

                return (
                    `${index + 1}. ${event.title || "Event"}\n` +
                    `Date: ${event.date || "N/A"}\n` +
                    `Time: ${event.time || "N/A"}\n` +
                    `Venue: ${event.venue || "N/A"}`
                );
            })
            .join("\n\n");

        return {
            answer:
                `📅 Relevant campus events:\n\n${answer}`,
            results
        };
    }

    // --------------------------------------------------------
    // ANNOUNCEMENTS
    // --------------------------------------------------------

    if (best.category === "announcements") {
        const announcements = results.filter(
            result =>
                result.category === "announcements"
        );

        const answer = announcements
            .slice(0, 5)
            .map((result, index) => {
                const item = result.item;

                return (
                    `${index + 1}. ${item.title || "Announcement"}\n` +
                    `Date: ${item.date || "N/A"}\n` +
                    `Priority: ${item.priority || "N/A"}\n` +
                    `${item.message || ""}`
                );
            })
            .join("\n\n");

        return {
            answer:
                `📢 Relevant announcements:\n\n${answer}`,
            results
        };
    }

    // --------------------------------------------------------
    // DEPARTMENT
    // --------------------------------------------------------

    if (best.category === "departments") {
        const item = best.item;

        return {
            answer:
                `🎓 Department information:\n\n` +
                `Department: ${item.name || "N/A"}\n` +
                `Short Name: ${item.shortName || "N/A"}\n` +
                `Building: ${item.building || "N/A"}\n` +
                `Floor: ${item.floor ?? "N/A"}`,
            results
        };
    }

    // --------------------------------------------------------
    // EMERGENCY
    // --------------------------------------------------------

    if (best.category === "emergency") {
        const emergencyResults = results.filter(
            result =>
                result.category === "emergency"
        );

        const answer = emergencyResults
            .slice(0, 5)
            .map((result, index) => {
                const item = result.item;

                return (
                    `${index + 1}. ${item.service || "Emergency Service"}\n` +
                    `Contact: ${item.contact || "N/A"}\n` +
                    `${item.description || ""}`
                );
            })
            .join("\n\n");

        return {
            answer:
                `🚨 Campus emergency contacts:\n\n${answer}`,
            results
        };
    }

    // --------------------------------------------------------
    // GENERIC
    // --------------------------------------------------------

    const genericResults = results
        .slice(0, 5)
        .map((result, index) => {
            return (
                `${index + 1}. ${result.title}\n` +
                formatResult(result)
            );
        })
        .join("\n\n");

    return {
        answer:
            `🔎 I found this information:\n\n${genericResults}`,
        results
    };
}

// ============================================================
// MAIN AI PROCESS
// ============================================================

function processQuestion(question) {
    const data = getData();

    if (!question || !String(question).trim()) {
        return {
            answer:
                "Please ask me something about the campus."
        };
    }

    const cleanedQuestion =
        String(question).trim();

    // --------------------------------------------------------
    // SPECIAL QUESTIONS
    // --------------------------------------------------------

    const specialAnswer =
        handleSpecialQuestion(
            cleanedQuestion,
            data
        );

    if (specialAnswer) {
        return specialAnswer;
    }

    // --------------------------------------------------------
    // RAG RETRIEVAL
    // --------------------------------------------------------

    const rag = buildContext(
        cleanedQuestion,
        5
    );

    const results = rag.results;

    // --------------------------------------------------------
    // GROUNDED RESPONSE
    // --------------------------------------------------------

    const response =
        generateAnswer(
            cleanedQuestion,
            results,
            data
        );

    // --------------------------------------------------------
    // RAG METADATA
    // --------------------------------------------------------

    return {
        ...response,

        rag: {
            enabled: true,
            retrievedDocuments: results.length,
            contextUsed: results.length > 0
        }
    };
}

// ============================================================
// EXPORT
// ============================================================

module.exports = {
    processQuestion
};