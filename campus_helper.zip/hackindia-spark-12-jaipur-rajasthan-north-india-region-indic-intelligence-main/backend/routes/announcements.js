const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");
const { filterData } = require("../utils/helpers");

router.get("/", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        count: data.announcements.length,
        data: data.announcements
    });
});

router.get("/latest", (req, res) => {
    const data = getData();

    const latest = [...data.announcements]
        .sort(
            (a, b) =>
                new Date(b.date) -
                new Date(a.date)
        )
        .slice(0, 5);

    res.json({
        success: true,
        data: latest
    });
});

router.get("/search", (req, res) => {
    const data = getData();
    const { q } = req.query;

    const results = filterData(
        data.announcements,
        q
    );

    res.json({
        success: true,
        query: q || "",
        count: results.length,
        data: results
    });
});

module.exports = router;