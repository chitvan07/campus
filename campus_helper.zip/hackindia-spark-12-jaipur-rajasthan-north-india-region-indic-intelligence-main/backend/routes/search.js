const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");
const { objectContainsQuery } = require("../utils/helpers");

router.get("/", (req, res) => {
    const { q } = req.query;

    if (!q || !q.trim()) {
        return res.status(400).json({
            success: false,
            message: "Search query is required"
        });
    }

    const data = getData();
    const query = q.trim();

    const results = {
        buildings: [],
        classrooms: [],
        food: [],
        events: [],
        announcements: [],
        departments: [],
        emergency: []
    };

    for (const category of Object.keys(results)) {
        results[category] =
            data[category].filter(item =>
                objectContainsQuery(item, query)
            );
    }

    // Library is an object
    if (
        objectContainsQuery(
            data.library,
            query
        )
    ) {
        results.library = data.library;
    } else {
        results.library = null;
    }

    res.json({
        success: true,
        query,
        data: results
    });
});

module.exports = router;