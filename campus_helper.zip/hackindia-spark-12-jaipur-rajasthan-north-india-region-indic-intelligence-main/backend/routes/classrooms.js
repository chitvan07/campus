const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");
const { filterData } = require("../utils/helpers");

router.get("/", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        count: data.classrooms.length,
        data: data.classrooms
    });
});

router.get("/search", (req, res) => {
    const data = getData();
    const { q } = req.query;

    const results = filterData(
        data.classrooms,
        q
    );

    res.json({
        success: true,
        query: q || "",
        count: results.length,
        data: results
    });
});

router.get("/:code", (req, res) => {
    const data = getData();

    const classroom = data.classrooms.find(
        item =>
            item.code.toLowerCase() ===
            req.params.code.toLowerCase()
    );

    if (!classroom) {
        return res.status(404).json({
            success: false,
            message: "Classroom not found"
        });
    }

    res.json({
        success: true,
        data: classroom
    });
});

module.exports = router;