const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");
const { filterData } = require("../utils/helpers");


// ============================================================
// GET ALL FOOD / CANTEENS
// ============================================================

router.get("/", (req, res) => {

    const data = getData();

    const food = Array.isArray(data.food)
        ? data.food
        : [];

    res.json({
        success: true,
        count: food.length,
        data: food
    });
});


// ============================================================
// GET FOOD TIMINGS
// ============================================================

router.get("/timings", (req, res) => {

    const data = getData();

    res.json({
        success: true,
        data: data.foodTimings || {}
    });
});


// ============================================================
// SEARCH FOOD
// ============================================================

router.get("/search", (req, res) => {

    const data = getData();

    const { q } = req.query;

    const food = Array.isArray(data.food)
        ? data.food
        : [];

    if (!q || !q.trim()) {

        return res.json({
            success: true,
            query: "",
            count: food.length,
            data: food
        });
    }

    const results = filterData(food, q);

    res.json({
        success: true,
        query: q,
        count: results.length,
        data: results
    });
});


// ============================================================
// GET SINGLE FOOD / CANTEEN
// ============================================================

router.get("/:id", (req, res) => {

    const data = getData();

    const food = Array.isArray(data.food)
        ? data.food
        : [];

    const item = food.find(
        foodItem => foodItem.id === req.params.id
    );

    if (!item) {

        return res.status(404).json({
            success: false,
            message: "Food outlet not found"
        });
    }

    res.json({
        success: true,
        data: item
    });
});


module.exports = router;