const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");
const { filterData } = require("../utils/helpers");

router.get("/", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        count: data.buildings.length,
        data: data.buildings
    });
});

router.get("/search", (req, res) => {
    const data = getData();
    const { q } = req.query;

    const results = filterData(
        data.buildings,
        q
    );

    res.json({
        success: true,
        query: q || "",
        count: results.length,
        data: results
    });
});

router.get("/:id", (req, res) => {
    const data = getData();

    const building = data.buildings.find(
        item => item.id === req.params.id
    );

    if (!building) {
        return res.status(404).json({
            success: false,
            message: "Building not found"
        });
    }

    res.json({
        success: true,
        data: building
    });
});

module.exports = router;