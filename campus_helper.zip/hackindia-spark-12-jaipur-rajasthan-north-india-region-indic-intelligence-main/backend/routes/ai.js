
const express = require("express");

const router = express.Router();

const {
    processQuestion
} = require("../utils/aiEngine");

// POST /api/ai/ask
router.post("/ask", (req, res) => {
    // Accept both "question" and "message"
    const question = req.body.question || req.body.message;

    if (!question) {
        return res.status(400).json({
            success: false,
            message: "Question is required"
        });
    }

    try {
        const result = processQuestion(question);

        res.json({
            success: true,
            question,
            ...result
        });
    } catch (error) {
        console.error("AI Error:", error);

        res.status(500).json({
            success: false,
            message: "AI failed to process the question"
        });
    }
});

// GET /api/ai/ask?question=...
router.get("/ask", (req, res) => {
    const question = req.query.question || req.query.message;

    if (!question) {
        return res.status(400).json({
            success: false,
            message: "Question is required"
        });
    }

    try {
        const result = processQuestion(question);

        res.json({
            success: true,
            question,
            ...result
        });
    } catch (error) {
        console.error("AI Error:", error);

        res.status(500).json({
            success: false,
            message: "AI failed to process the question"
        });
    }
});

module.exports = router;

