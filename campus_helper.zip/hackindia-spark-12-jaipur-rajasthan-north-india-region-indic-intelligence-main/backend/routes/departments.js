const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");
const { filterData } = require("../utils/helpers");

router.get("/", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        count: data.departments.length,
        data: data.departments
    });
});

router.get("/search", (req, res) => {
    const data = getData();
    const { q } = req.query;

    const results = filterData(
        data.departments,
        q
    );

    res.json({
        success: true,
        query: q || "",
        count: results.length,
        data: results
    });
});

router.get("/:shortName", (req, res) => {
    const data = getData();

    const department = data.departments.find(
        item =>
            item.shortName.toLowerCase() ===
            req.params.shortName.toLowerCase()
    );

    if (!department) {
        return res.status(404).json({
            success: false,
            message: "Department not found"
        });
    }

    res.json({
        success: true,
        data: department
    });
});

module.exports = router;