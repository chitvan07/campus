const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");

router.get("/", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        data: data.campus
    });
});

router.get("/info", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        data: data.campus
    });
});

module.exports = router;