const express = require("express");

const router = express.Router();

router.get("/", (req, res) => {
    res.json({
        success: true,
        status: "OK",
        message: "College Sarthi backend is running",
        timestamp: new Date().toISOString()
    });
});

module.exports = router;