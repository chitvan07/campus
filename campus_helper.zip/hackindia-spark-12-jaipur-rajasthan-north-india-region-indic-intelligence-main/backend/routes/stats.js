const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");

router.get("/", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        data: {
            buildings: data.buildings.length,
            classrooms: data.classrooms.length,
            foodOutlets: data.food.length,
            events: data.events.length,
            announcements:
                data.announcements.length,
            departments:
                data.departments.length,
            emergencyServices:
                data.emergency.length,
            libraryFloors:
                data.library.floors.length
        }
    });
});

module.exports = router;