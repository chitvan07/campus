const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");

router.get("/", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        count: data.emergency.length,
        data: data.emergency
    });
});

router.get("/:service", (req, res) => {
    const data = getData();

    const service = data.emergency.find(
        item =>
            item.service.toLowerCase() ===
            req.params.service.toLowerCase()
    );

    if (!service) {
        return res.status(404).json({
            success: false,
            message: "Emergency service not found"
        });
    }

    res.json({
        success: true,
        data: service
    });
});

module.exports = router;