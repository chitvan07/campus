const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");
const { filterData } = require("../utils/helpers");

router.get("/", (req, res) => {
    const data = getData();

    res.json({
        success: true,
        count: data.events.length,
        data: data.events
    });
});

router.get("/search", (req, res) => {
    const data = getData();
    const { q } = req.query;

    const results = filterData(
        data.events,
        q
    );

    res.json({
        success: true,
        query: q || "",
        count: results.length,
        data: results
    });
});

router.get("/:id", (req, res) => {
    const data = getData();

    const event = data.events.find(
        item =>
            String(item.id) ===
            String(req.params.id)
    );

    if (!event) {
        return res.status(404).json({
            success: false,
            message: "Event not found"
        });
    }

    res.json({
        success: true,
        data: event
    });
});

module.exports = router;