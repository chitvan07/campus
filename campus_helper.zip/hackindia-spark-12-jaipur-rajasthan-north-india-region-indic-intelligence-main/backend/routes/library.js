const express = require("express");

const router = express.Router();

const { getData } = require("../utils/data");


// ============================================================
// GET COMPLETE LIBRARY INFORMATION
// ============================================================

router.get("/", (req, res) => {

    const data = getData();

    const library = data.library || {};

    res.json({
        success: true,
        data: library
    });

});


// ============================================================
// GET LIBRARY FLOOR-WISE AVAILABILITY
// ============================================================

router.get("/availability", (req, res) => {

    const data = getData();

    const library = data.library || {};

    const floors = Array.isArray(library.floors)
        ? library.floors
        : [];


    const result = floors.map(floor => {

        const totalSeats =
            Number(floor.totalSeats || 0);

        const availableSeats =
            Number(floor.availableSeats || 0);

        const occupiedSeats =
            Math.max(
                0,
                totalSeats - availableSeats
            );

        const occupancyPercentage =
            totalSeats > 0
                ? Math.round(
                    (occupiedSeats / totalSeats) * 100
                )
                : 0;


        return {

            name: floor.name,

            totalSeats,

            availableSeats,

            occupiedSeats,

            occupancyPercentage,

            status:
                floor.status || "Unknown"

        };

    });


    res.json({

        success: true,

        library: {
            name:
                library.name ||
                "Central Library",

            timings:
                library.timings ||
                "Not available",

            overallCapacity:
                library.overallCapacity || 0,

            status:
                library.status ||
                "Unknown"
        },

        count: result.length,

        data: result

    });

});


// ============================================================
// GET SINGLE FLOOR
// ============================================================

router.get("/floor/:floorName", (req, res) => {

    const data = getData();

    const library = data.library || {};

    const floors = Array.isArray(library.floors)
        ? library.floors
        : [];


    const requestedFloor =
        decodeURIComponent(
            req.params.floorName
        ).toLowerCase();


    const floor =
        floors.find(item =>
            String(item.name || "")
                .toLowerCase() ===
            requestedFloor
        );


    if (!floor) {

        return res.status(404).json({

            success: false,

            message:
                "Library floor not found"

        });

    }


    const totalSeats =
        Number(floor.totalSeats || 0);

    const availableSeats =
        Number(floor.availableSeats || 0);

    const occupiedSeats =
        Math.max(
            0,
            totalSeats - availableSeats
        );


    const occupancyPercentage =
        totalSeats > 0
            ? Math.round(
                (occupiedSeats / totalSeats) * 100
            )
            : 0;


    res.json({

        success: true,

        data: {

            ...floor,

            totalSeats,

            availableSeats,

            occupiedSeats,

            occupancyPercentage

        }

    });

});


module.exports = router;