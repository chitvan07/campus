const express = require("express");

const router = express.Router();

const complaints = [];

router.get("/", (req, res) => {
    res.json({
        success: true,
        count: complaints.length,
        data: complaints
    });
});

router.post("/", (req, res) => {
    const {
        name,
        email,
        subject,
        description,
        category
    } = req.body;

    if (!subject || !description) {
        return res.status(400).json({
            success: false,
            message:
                "Subject and description are required"
        });
    }

    const complaint = {
        id: complaints.length + 1,
        name: name || "Anonymous",
        email: email || "",
        subject,
        description,
        category: category || "General",
        status: "Pending",
        createdAt:
            new Date().toISOString()
    };

    complaints.push(complaint);

    res.status(201).json({
        success: true,
        message:
            "Complaint submitted successfully",
        data: complaint
    });
});

module.exports = router;