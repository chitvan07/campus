
// ============================================================
// CAMPUS HELPER AI - SIGNUP
// ============================================================

const signupForm =
    document.getElementById("signupForm");

const passwordInput =
    document.getElementById("signupPassword");


// ============================================================
// SIGNUP SUBMIT
// ============================================================

signupForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();

        const email =
            document
                .getElementById("signupEmail")
                .value
                .trim()
                .toLowerCase();

        const password =
            document
                .getElementById("signupPassword")
                .value;

        const confirmPassword =
            document
                .getElementById("confirmPassword")
                .value;

        const button =
            document.getElementById("signupButton");

        const message =
            document.getElementById("signupMessage");


        // Clear old message
        message.textContent = "";
        message.className = "form-message";


        // ====================================================
        // VALIDATION
        // ====================================================

        if (!email || !password || !confirmPassword) {

            showMessage(
                "Please fill all fields.",
                "error"
            );

            return;
        }


        if (password.length < 6) {

            showMessage(
                "Password must be at least 6 characters.",
                "error"
            );

            return;
        }


        if (password !== confirmPassword) {

            showMessage(
                "Passwords do not match.",
                "error"
            );

            return;
        }


        // ====================================================
        // LOADING
        // ====================================================

        button.disabled = true;
        button.textContent = "Creating Account...";


        try {

            const response = await fetch(
                "http://localhost:5000/api/auth/signup",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email,
                        password
                    })
                }
            );


            const data =
                await response.json();


            // =================================================
            // SUCCESS
            // =================================================

            if (data.success) {

                showMessage(
                    "Account created successfully! Redirecting to login...",
                    "success"
                );

                setTimeout(() => {

                    window.location.href =
                        "login.html";

                }, 1000);

                return;
            }


            // =================================================
            // FAILED
            // =================================================

            showMessage(
                data.message || "Signup failed.",
                "error"
            );

        } catch (error) {

            console.error(
                "Signup error:",
                error
            );

            showMessage(
                "Unable to connect to server. Make sure the backend is running.",
                "error"
            );

        } finally {

            button.disabled = false;
            button.textContent = "Create Account";
        }
    }
);


// ============================================================
// PASSWORD STRENGTH
// ============================================================

passwordInput.addEventListener(
    "input",
    function () {

        const password =
            passwordInput.value;

        const strengthBox =
            document.getElementById(
                "passwordStrength"
            );

        const strengthFill =
            document.getElementById(
                "passwordStrengthFill"
            );


        if (!password) {

            strengthBox.style.display =
                "none";

            return;
        }


        strengthBox.style.display =
            "block";


        let score = 0;


        // Length
        if (password.length >= 6) {
            score++;
        }

        // Uppercase
        if (/[A-Z]/.test(password)) {
            score++;
        }

        // Number
        if (/[0-9]/.test(password)) {
            score++;
        }

        // Special character
        if (/[^A-Za-z0-9]/.test(password)) {
            score++;
        }


        if (score === 1) {

            strengthBox.firstChild.textContent =
                "Weak";

            strengthFill.style.width =
                "25%";

        } else if (score === 2) {

            strengthBox.firstChild.textContent =
                "Medium";

            strengthFill.style.width =
                "50%";

        } else if (score === 3) {

            strengthBox.firstChild.textContent =
                "Good";

            strengthFill.style.width =
                "75%";

        } else {

            strengthBox.firstChild.textContent =
                "Strong";

            strengthFill.style.width =
                "100%";
        }
    }
);


// ============================================================
// SHOW / HIDE PASSWORD
// ============================================================

function togglePassword(inputId, button) {

    const input =
        document.getElementById(inputId);


    if (input.type === "password") {

        input.type = "text";

        button.textContent = "🙈";

        button.setAttribute(
            "aria-label",
            "Hide password"
        );

    } else {

        input.type = "password";

        button.textContent = "👁️";

        button.setAttribute(
            "aria-label",
            "Show password"
        );
    }
}


// ============================================================
// MESSAGE
// ============================================================

function showMessage(text, type) {

    const message =
        document.getElementById(
            "signupMessage"
        );

    message.textContent = text;

    message.className =
        `form-message ${type}`;
}
