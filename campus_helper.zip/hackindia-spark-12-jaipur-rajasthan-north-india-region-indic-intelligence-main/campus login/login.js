
// ============================================================
// CAMPUS HELPER AI - LOGIN
// ============================================================

document.addEventListener("DOMContentLoaded", () => {

    const loginForm = document.getElementById("loginForm");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const loginButton = document.getElementById("loginButton");
    const loginMessage = document.getElementById("loginMessage");
    const togglePasswordButton =
        document.getElementById("togglePassword");


    // ========================================================
    // LOGIN FORM
    // ========================================================

    loginForm.addEventListener("submit", async (event) => {

        event.preventDefault();

        const email = emailInput.value.trim().toLowerCase();
        const password = passwordInput.value;


        // Clear old message
        loginMessage.textContent = "";
        loginMessage.className = "form-message";


        // ====================================================
        // VALIDATION
        // ====================================================

        if (!email || !password) {

            showMessage(
                "Please enter email and password.",
                "error"
            );

            return;
        }


        // ====================================================
        // LOADING
        // ====================================================

        loginButton.disabled = true;
        loginButton.textContent = "Logging in...";


        try {

            console.log("Login request started:", email);


            const response = await fetch(
                "http://localhost:5000/api/auth/login",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        password: password
                    })
                }
            );


            console.log(
                "Server response status:",
                response.status
            );


            const data = await response.json();


            console.log(
                "Server response:",
                data
            );


            // =================================================
            // SUCCESS
            // =================================================

            if (response.ok && data.success) {

                localStorage.setItem(
                    "campusHelperUser",
                    JSON.stringify(data.user)
                );


                showMessage(
                    "Login successful! Opening Campus Helper...",
                    "success"
                );


                setTimeout(() => {

                    window.location.href =
                        "../frontend/index.html";

                }, 700);


                return;
            }


            // =================================================
            // LOGIN FAILED
            // =================================================

            showMessage(
                data.message ||
                "Invalid email or password.",
                "error"
            );

        }

        catch (error) {

            console.error(
                "Login error:",
                error
            );


            showMessage(
                "Unable to connect to backend. Make sure the server is running on port 5000.",
                "error"
            );

        }

        finally {

            loginButton.disabled = false;
            loginButton.textContent = "Login";

        }

    });


    // ========================================================
    // SHOW / HIDE PASSWORD
    // ========================================================

    togglePasswordButton.addEventListener(
        "click",
        () => {

            if (
                passwordInput.type === "password"
            ) {

                passwordInput.type = "text";

                togglePasswordButton.textContent =
                    "🙈";

            } else {

                passwordInput.type = "password";

                togglePasswordButton.textContent =
                    "👁️";

            }

        }
    );

});


// ============================================================
// MESSAGE FUNCTION
// ============================================================

function showMessage(text, type) {

    const message =
        document.getElementById("loginMessage");

    message.textContent = text;

    message.className =
        `form-message ${type}`;

}

