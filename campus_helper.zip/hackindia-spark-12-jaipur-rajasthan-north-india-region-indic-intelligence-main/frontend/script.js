// ============================================================
// AUTHENTICATION CHECK
// ============================================================

const campusHelperUser =
    localStorage.getItem("campusHelperUser");

if (!campusHelperUser) {
    window.location.href = "../campus login/login.html";
}

// ============================================================
// CAMPUS HELPER AI - FRONTEND JAVASCRIPT
// Connected with Modular Backend + LIVE GOOGLE MAPS
// ============================================================

const API = "http://localhost:5000/api";

let campusData = {};
let buildings = [];
let classrooms = [];
let foodSpots = [];
let libraryData = {};
let events = [];
let departments = [];
let announcements = [];
let complaints = [];


// ============================================================
// GOOGLE MAP VARIABLES
// ============================================================

let campusMap = null;
let googleMapsReady = false;
let mapMarkers = [];

let pietMarker = null;
let pietInfoWindow = null;

// Selected location marker
let selectedLocationMarker = null;
let selectedLocationInfoWindow = null;
let selectedLocationAnimationTimer = null;
let selectedLocationZoomTimer = null;
let mapGeocoder = null;

const PIET_LOCATION = {
    lat: 26.768086,
    lng: 75.850625
};

const PIET_MAP_SETTINGS = {
    zoom: 19,
    minZoom: 17,
    maxZoom: 21
};


// ============================================================
// API HELPER
// ============================================================

async function api(endpoint, options = {}) {

    try {

        const response =
            await fetch(
                API + endpoint,
                options
            );

        let result;

        try {

            result =
                await response.json();

        } catch {

            result = {
                success: false,
                message: "Invalid server response"
            };
        }

        if (!response.ok) {

            throw new Error(
                result.message ||
                "API request failed"
            );
        }

        return result;

    } catch (error) {

        console.error(
            "API Error:",
            endpoint,
            error
        );

        showToast(
            error.message ||
            "Unable to connect to Campus Helper server",
            "error"
        );

        return null;
    }
}


// ============================================================
// INITIALIZATION
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    initializeApp
);

async function initializeApp() {

    loadTheme();

    setupGlobalSearch();

    setupAI();

    setupComplaintForm();

    createFoodModal();

    createLibraryModal();

    createEventModal();

    await loadCampusData();

    await loadAnnouncements();

    await loadComplaints();

    await loadEmergency();

    console.log(
        "✅ Campus Helper initialized successfully"
    );
}


// ============================================================
// LIVE GOOGLE MAP INITIALIZATION
// ============================================================

async function initCampusMap() {

    try {

        const mapContainer =
            document.getElementById(
                "campus-map"
            );

        if (!mapContainer) {

            console.warn(
                "Google Maps container not found."
            );

            return;
        }

        if (campusMap) {

            refreshGoogleMap();

            return;
        }

        if (
            typeof google === "undefined" ||
            !google.maps
        ) {

            console.error(
                "Google Maps JavaScript API is not loaded."
            );

            showMapError(
                "Google Maps API is not loaded. Please check the Google Maps JavaScript API in your Google Cloud project."
            );

            return;
        }

        const { Map } =
            await google.maps.importLibrary(
                "maps"
            );

        campusMap =
            new Map(
                mapContainer,
                {

                    center:
                        PIET_LOCATION,

                    zoom:
                        PIET_MAP_SETTINGS.zoom,

                    minZoom:
                        PIET_MAP_SETTINGS.minZoom,

                    maxZoom:
                        PIET_MAP_SETTINGS.maxZoom,

                    mapTypeId:
                        google.maps.MapTypeId.SATELLITE,

                    mapTypeControl: true,

                    mapTypeControlOptions: {
                        style:
                            google.maps.MapTypeControlStyle.HORIZONTAL_BAR,

                        mapTypeIds: [
                            "roadmap",
                            "satellite",
                            "hybrid"
                        ]
                    },

                    streetViewControl: true,

                    fullscreenControl: true,

                    zoomControl: true,

                    scaleControl: true,

                    rotateControl: true,

                    gestureHandling: "greedy",

                    clickableIcons: true,

                    tilt: 0
                }
            );

        googleMapsReady = true;

        console.log(
            "🛰️ LIVE Google Maps Satellite View loaded"
        );

        addPIETMarker();

        renderGoogleMapMarkers();

        setTimeout(() => {

            if (!campusMap) return;

            try {

                google.maps.event.trigger(
                    campusMap,
                    "resize"
                );

                campusMap.setCenter(
                    PIET_LOCATION
                );

                campusMap.setZoom(
                    PIET_MAP_SETTINGS.zoom
                );

                campusMap.setMapTypeId(
                    google.maps.MapTypeId.SATELLITE
                );

            } catch (error) {

                console.error(
                    "Initial map resize error:",
                    error
                );
            }

        }, 300);

    } catch (error) {

        console.error(
            "Google Maps Error:",
            error
        );

        showMapError(
            "Google Maps could not load. Please check that Maps JavaScript API is enabled and your API key has the correct restrictions."
        );
    }
}


// ============================================================
// PIET MARKER
// ============================================================

function addPIETMarker() {

    if (
        !campusMap ||
        typeof google === "undefined" ||
        !google.maps
    ) {
        return;
    }

    if (pietMarker) {

        pietMarker.setMap(null);

        pietMarker = null;
    }

    pietMarker =
        new google.maps.Marker({

            position:
                PIET_LOCATION,

            map:
                campusMap,

            title:
                "Poornima Institute of Engineering & Technology",

            animation:
                google.maps.Animation.DROP,

            zIndex: 9999
        });

    pietInfoWindow =
        new google.maps.InfoWindow({

            content: `

                <div style="
                    min-width:230px;
                    max-width:300px;
                    padding:6px;
                    font-family:Arial,sans-serif;
                ">

                    <h3 style="
                        margin:0 0 8px;
                        font-size:17px;
                    ">
                        🎓 Poornima Institute of Engineering & Technology
                    </h3>

                    <p style="
                        margin:5px 0;
                        line-height:1.5;
                    ">
                        📍 Sitapura, Jaipur, Rajasthan
                    </p>

                    <p style="
                        margin:5px 0;
                        font-size:13px;
                        color:#555;
                    ">
                        🛰️ Live Google Satellite View
                    </p>

                </div>
            `
        });

    pietMarker.addListener(
        "click",
        () => {

            if (!campusMap) return;

            campusMap.panTo(
                PIET_LOCATION
            );

            campusMap.setZoom(
                PIET_MAP_SETTINGS.zoom
            );

            pietInfoWindow.open(
                campusMap,
                pietMarker
            );
        }
    );
}


// ============================================================
// FOCUS MAP ON PIET
// ============================================================

function focusMapOnPIET(openInfo = false) {

    if (!campusMap) {

        refreshGoogleMap();

        return;
    }

    try {

        clearSelectedMapLocation();

        campusMap.setMapTypeId(
            google.maps.MapTypeId.SATELLITE
        );

        campusMap.panTo(
            PIET_LOCATION
        );

        campusMap.setZoom(
            PIET_MAP_SETTINGS.zoom
        );

        if (!pietMarker) {
            addPIETMarker();
        }

        if (
            openInfo &&
            pietInfoWindow &&
            pietMarker
        ) {

            pietInfoWindow.open(
                campusMap,
                pietMarker
            );
        }

    } catch (error) {

        console.error(
            "PIET map focus error:",
            error
        );
    }
}


// ============================================================
// GOOGLE MAP ERROR
// ============================================================

function showMapError(message) {

    const container =
        document.getElementById(
            "campus-map"
        );

    if (!container) return;

    container.innerHTML = `

        <div style="
            min-height:500px;
            height:100%;
            display:flex;
            align-items:center;
            justify-content:center;
            text-align:center;
            padding:30px;
            background:#f5f7fa;
            border-radius:16px;
        ">

            <div>

                <div style="
                    font-size:52px;
                    margin-bottom:15px;
                ">
                    🗺️
                </div>

                <h3>
                    Google Maps could not load
                </h3>

                <p style="
                    max-width:500px;
                    margin:10px auto;
                    line-height:1.6;
                ">
                    ${escapeHTML(message)}
                </p>

                <button
                    onclick="location.reload()"
                    style="
                        margin-top:15px;
                        padding:10px 20px;
                        border:none;
                        border-radius:8px;
                        cursor:pointer;
                    "
                >
                    🔄 Reload Map
                </button>

            </div>

        </div>
    `;
}


// ============================================================
// GOOGLE MAP CALLBACK
// ============================================================

window.initCampusMap =
    initCampusMap;

window.refreshGoogleMap =
    refreshGoogleMap;

window.focusMapOnPIET =
    focusMapOnPIET;


// ============================================================
// MAP SELECTED LOCATION HELPERS
// ============================================================

function getMapGeocoder() {

    if (
        !mapGeocoder &&
        typeof google !== "undefined" &&
        google.maps &&
        google.maps.Geocoder
    ) {

        mapGeocoder =
            new google.maps.Geocoder();
    }

    return mapGeocoder;
}


function clearSelectedMapLocation() {

    if (selectedLocationAnimationTimer) {

        clearTimeout(
            selectedLocationAnimationTimer
        );

        selectedLocationAnimationTimer = null;
    }

    if (selectedLocationZoomTimer) {

        clearInterval(
            selectedLocationZoomTimer
        );

        selectedLocationZoomTimer = null;
    }

    if (selectedLocationInfoWindow) {

        try {
            selectedLocationInfoWindow.close();
        } catch (error) {
            console.warn(
                "InfoWindow close error:",
                error
            );
        }

        selectedLocationInfoWindow = null;
    }

    if (selectedLocationMarker) {

        try {
            selectedLocationMarker.setAnimation(null);
            selectedLocationMarker.setMap(null);
        } catch (error) {
            console.warn(
                "Selected marker cleanup error:",
                error
            );
        }

        selectedLocationMarker = null;
    }
}


function getLocationDisplayName(item) {

    if (!item) {
        return "Selected Location";
    }

    return (
        item.name ||
        item.code ||
        item.title ||
        item.service ||
        "Selected Location"
    );
}


function getLocationType(item) {

    if (!item) {
        return "Campus Location";
    }

    if (item.code) {
        return "Classroom";
    }

    if (item.type) {
        return item.type;
    }

    if (item.category) {
        return item.category;
    }

    if (item.name) {
        return "Campus Location";
    }

    return "Campus Location";
}


function getLocationFallbackAddress(item) {

    if (!item) {
        return "PIET Campus, Sitapura, Jaipur, Rajasthan";
    }

    if (item.address) {
        return String(item.address);
    }

    if (item.location) {
        return String(item.location);
    }

    if (item.building) {

        return (
            String(item.building) +
            ", PIET Campus, Sitapura, Jaipur, Rajasthan"
        );
    }

    return "PIET Campus, Sitapura, Jaipur, Rajasthan";
}


function resolveLocationCoordinates(item) {

    const direct =
        getCoordinates(item);

    if (direct) {
        return direct;
    }

    if (item && item.building) {

        const parentBuilding =
            buildings.find(
                building =>
                    String(
                        building.name || ""
                    ).trim().toLowerCase() ===
                    String(
                        item.building || ""
                    ).trim().toLowerCase()
            );

        if (parentBuilding) {

            const parentCoordinates =
                getCoordinates(
                    parentBuilding
                );

            if (parentCoordinates) {
                return parentCoordinates;
            }
        }
    }

    if (item && item.venue) {

        const venueText =
            String(
                item.venue || ""
            ).trim().toLowerCase();

        const parentBuilding =
            buildings.find(
                building => {

                    const buildingName =
                        String(
                            building.name || ""
                        ).trim().toLowerCase();

                    return (
                        venueText === buildingName ||
                        venueText.includes(buildingName) ||
                        buildingName.includes(venueText)
                    );
                }
            );

        if (parentBuilding) {

            const parentCoordinates =
                getCoordinates(
                    parentBuilding
                );

            if (parentCoordinates) {
                return parentCoordinates;
            }
        }
    }

    return null;
}


function createSelectedLocationInfo(
    item,
    address,
    isParentLocation = false
) {

    const name =
        getLocationDisplayName(item);

    const type =
        getLocationType(item);

    const description =
        item?.description ||
        "";

    return `

        <div style="
            min-width:240px;
            max-width:330px;
            padding:7px;
            font-family:Arial,sans-serif;
        ">

            <div style="
                display:flex;
                align-items:center;
                gap:8px;
                margin-bottom:8px;
            ">

                <span style="
                    font-size:23px;
                ">
                    📍
                </span>

                <div>

                    <div style="
                        font-size:11px;
                        font-weight:700;
                        letter-spacing:.8px;
                        text-transform:uppercase;
                        color:#2563eb;
                        margin-bottom:2px;
                    ">
                        Selected Location
                    </div>

                    <h3 style="
                        margin:0;
                        font-size:17px;
                        line-height:1.3;
                    ">
                        ${escapeHTML(name)}
                    </h3>

                </div>

            </div>

            <div style="
                margin:9px 0;
                padding:9px 10px;
                border-radius:9px;
                background:rgba(37,99,235,.08);
            ">

                <div style="
                    font-size:12px;
                    font-weight:700;
                    color:#2563eb;
                    margin-bottom:3px;
                ">
                    ${escapeHTML(type)}
                </div>

                <div style="
                    font-size:13px;
                    line-height:1.5;
                    color:#333;
                ">
                    📌 ${escapeHTML(address)}
                </div>

            </div>

            ${
                isParentLocation
                    ? `
                        <div style="
                            font-size:12px;
                            color:#666;
                            margin-top:8px;
                        ">
                            ℹ️ Exact coordinates for this location
                            are not available. Showing its parent
                            building location.
                        </div>
                    `
                    : ""
            }

            ${
                description
                    ? `
                        <div style="
                            margin-top:8px;
                            font-size:12px;
                            line-height:1.5;
                            color:#555;
                        ">
                            ${escapeHTML(description)}
                        </div>
                    `
                    : ""
            }

        </div>
    `;
}


function animateMapZoomToTarget(
    coordinates
) {

    if (!campusMap) return;

    if (selectedLocationZoomTimer) {

        clearInterval(
            selectedLocationZoomTimer
        );

        selectedLocationZoomTimer = null;
    }

    try {

        const currentZoom =
            Number(
                campusMap.getZoom() ||
                PIET_MAP_SETTINGS.zoom
            );

        const targetZoom =
            PIET_MAP_SETTINGS.maxZoom;

        if (currentZoom >= targetZoom) {

            campusMap.setZoom(
                targetZoom
            );

            return;
        }

        let zoom =
            Math.floor(currentZoom);

        selectedLocationZoomTimer =
            setInterval(() => {

                if (!campusMap) {

                    clearInterval(
                        selectedLocationZoomTimer
                    );

                    selectedLocationZoomTimer = null;

                    return;
                }

                zoom += 1;

                campusMap.setZoom(
                    Math.min(
                        zoom,
                        targetZoom
                    )
                );

                if (zoom >= targetZoom) {

                    clearInterval(
                        selectedLocationZoomTimer
                    );

                    selectedLocationZoomTimer = null;
                }

            }, 180);

    } catch (error) {

        console.error(
            "Map zoom animation error:",
            error
        );

        campusMap.setZoom(
            targetZoom
        );
    }
}


function animateSelectedLocationMarker(
    item,
    coordinates,
    address,
    isParentLocation = false
) {

    if (!campusMap) return;

    clearSelectedMapLocation();

    const title =
        getLocationDisplayName(item);

    selectedLocationMarker =
        new google.maps.Marker({

            position:
                coordinates,

            map:
                campusMap,

            title:
                title,

            animation:
                google.maps.Animation.DROP,

            zIndex: 10000
        });

    selectedLocationInfoWindow =
        new google.maps.InfoWindow({

            content:
                createSelectedLocationInfo(
                    item,
                    address,
                    isParentLocation
                )
        });

    selectedLocationMarker.addListener(
        "click",
        () => {

            if (
                selectedLocationInfoWindow &&
                campusMap &&
                selectedLocationMarker
            ) {

                selectedLocationInfoWindow.open(
                    campusMap,
                    selectedLocationMarker
                );
            }
        }
    );

    // Open information after the DROP animation starts
    setTimeout(() => {

        if (
            selectedLocationInfoWindow &&
            selectedLocationMarker &&
            campusMap
        ) {

            selectedLocationInfoWindow.open(
                campusMap,
                selectedLocationMarker
            );
        }

    }, 500);

    // Small BOUNCE after DROP
    selectedLocationAnimationTimer =
        setTimeout(() => {

            if (
                !selectedLocationMarker ||
                !campusMap
            ) {
                return;
            }

            selectedLocationMarker.setAnimation(
                google.maps.Animation.BOUNCE
            );

            selectedLocationAnimationTimer =
                setTimeout(() => {

                    if (selectedLocationMarker) {

                        selectedLocationMarker.setAnimation(
                            null
                        );
                    }

                }, 1400);

        }, 700);
}


function getLocationAddress(
    item,
    coordinates,
    isParentLocation = false
) {

    const fallbackAddress =
        getLocationFallbackAddress(item);

    const geocoder =
        getMapGeocoder();

    if (
        !geocoder ||
        !coordinates
    ) {

        return Promise.resolve(
            fallbackAddress
        );
    }

    return new Promise(resolve => {

        try {

            geocoder.geocode(
                {
                    location: coordinates
                },
                (results, status) => {

                    if (
                        status === "OK" &&
                        Array.isArray(results) &&
                        results.length
                    ) {

                        const formattedAddress =
                            results[0]
                                ?.formatted_address;

                        if (formattedAddress) {

                            resolve(
                                formattedAddress
                            );

                            return;
                        }
                    }

                    resolve(
                        fallbackAddress
                    );
                }
            );

        } catch (error) {

            console.error(
                "Google Geocoder error:",
                error
            );

            resolve(
                fallbackAddress
            );
        }
    });
}


async function showSelectedLocationOnMap(
    item,
    options = {}
) {

    if (!campusMap) {

        refreshGoogleMap();

        setTimeout(() => {

            showSelectedLocationOnMap(
                item,
                options
            );

        }, 700);

        return;
    }

    const directCoordinates =
        getCoordinates(item);

    const coordinates =
        resolveLocationCoordinates(item);

    if (!coordinates) {

        focusMapOnPIET();

        showToast(
            "Exact coordinates are not available for this location. Showing PIET campus.",
            "info"
        );

        return;
    }

    const isParentLocation =
        !directCoordinates &&
        !!item?.building;

    try {

        campusMap.setMapTypeId(
            google.maps.MapTypeId.SATELLITE
        );

        // Stop previous animations
        if (selectedLocationZoomTimer) {

            clearInterval(
                selectedLocationZoomTimer
            );

            selectedLocationZoomTimer = null;
        }

        // Move smoothly to selected location
        campusMap.panTo(
            coordinates
        );

        // Create selected pin immediately
        const fallbackAddress =
            getLocationFallbackAddress(item);

        animateSelectedLocationMarker(
            item,
            coordinates,
            fallbackAddress,
            isParentLocation
        );

        // Start zoom animation
        setTimeout(() => {

            animateMapZoomToTarget(
                coordinates
            );

        }, 180);

        // Fetch actual Google Maps address
        const address =
            await getLocationAddress(
                item,
                coordinates,
                isParentLocation
            );

        // Update InfoWindow with final address
        if (
            selectedLocationInfoWindow &&
            selectedLocationMarker
        ) {

            selectedLocationInfoWindow.setContent(
                createSelectedLocationInfo(
                    item,
                    address,
                    isParentLocation
                )
            );

            selectedLocationInfoWindow.open(
                campusMap,
                selectedLocationMarker
            );
        }

        if (options.toast !== false) {

            showToast(
                `📍 ${getLocationDisplayName(item)} found`,
                "success"
            );
        }

    } catch (error) {

        console.error(
            "Selected location map error:",
            error
        );

        focusMapOnPIET();

        showToast(
            "Unable to focus on this location.",
            "error"
        );
    }
}


// ============================================================
// LOAD CAMPUS DATA
// ============================================================

async function loadCampusData() {

    try {

        const results =
            await Promise.all([

                api("/campus"),

                api("/buildings"),

                api("/classrooms"),

                api("/food"),

                api("/library"),

                api("/events"),

                api("/departments")
            ]);

        campusData =
            results[0]?.data || {};

        buildings =
            Array.isArray(results[1]?.data)
                ? results[1].data
                : [];

        classrooms =
            Array.isArray(results[2]?.data)
                ? results[2].data
                : [];

        foodSpots =
            Array.isArray(results[3]?.data)
                ? results[3].data
                : [];

        libraryData =
            results[4]?.success &&
            results[4]?.data
                ? results[4].data
                : {};

        events =
            Array.isArray(results[5]?.data)
                ? results[5].data
                : [];

        departments =
            Array.isArray(results[6]?.data)
                ? results[6].data
                : [];

        updateDashboard();

        renderBuildings();

        renderFood();

        renderLibrary();

        renderEvents();

        renderAcademics();

        if (campusMap) {
            renderGoogleMapMarkers();
        }

    } catch (error) {

        console.error(
            "Campus data loading error:",
            error
        );
    }
}


// ============================================================
// PAGE NAVIGATION
// ============================================================

function showPage(
    pageName,
    clickedButton = null
) {

    document
        .querySelectorAll(".page")
        .forEach(page => {

            page.classList.remove("active");

        });

    const page =
        document.getElementById(
            `${pageName}-page`
        );

    if (!page) {

        showToast(
            `Page "${pageName}" not found`,
            "error"
        );

        return;
    }

    page.classList.add("active");

    document
        .querySelectorAll(".nav-item")
        .forEach(item => {

            item.classList.remove("active");

        });

    if (clickedButton) {

        clickedButton.classList.add("active");

    }

    const matchingNav =
        document.querySelector(
            `.nav-item[onclick*="'${pageName}'"]`
        );

    if (matchingNav) {

        matchingNav.classList.add("active");

    }

    switch (pageName) {

        case "dashboard":

            updateDashboard();

            break;

        case "assistant":

            setupAI();

            break;

        case "map":

            renderBuildings();

            setTimeout(() => {

                if (campusMap) {

                    refreshGoogleMap();

                } else if (
                    typeof google !== "undefined" &&
                    google.maps
                ) {

                    initCampusMap();

                }

            }, 300);

            break;

        case "food":

            renderFood();

            break;

        case "library":

            loadLibraryAvailability();

            break;

        case "events":

            renderEvents();

            break;

        case "academics":

            renderAcademics();

            break;

        case "complaints":

            loadComplaints();

            break;

        case "emergency":

            loadEmergency();

            break;
    }

    const sidebar =
        document.querySelector(
            ".sidebar"
        );

    if (sidebar) {

        sidebar.classList.remove(
            "mobile-open"
        );
    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


// ============================================================
// REFRESH LIVE GOOGLE MAP
// ============================================================

function refreshGoogleMap() {

    if (!campusMap) {

        if (
            typeof google !== "undefined" &&
            google.maps
        ) {

            initCampusMap();

        } else {

            console.warn(
                "Google Maps is not ready yet."
            );
        }

        return;
    }

    setTimeout(() => {

        try {

            google.maps.event.trigger(
                campusMap,
                "resize"
            );

            campusMap.setCenter(
                PIET_LOCATION
            );

            campusMap.setMapTypeId(
                google.maps.MapTypeId.SATELLITE
            );

            campusMap.setZoom(
                PIET_MAP_SETTINGS.zoom
            );

            if (!pietMarker) {
                addPIETMarker();
            }

            renderGoogleMapMarkers();

        } catch (error) {

            console.error(
                "Map refresh error:",
                error
            );
        }

    }, 150);
}


// ============================================================
// GOOGLE MAP MARKERS
// ============================================================

function renderGoogleMapMarkers() {

    if (!campusMap) return;

    if (
        typeof google === "undefined" ||
        !google.maps
    ) {
        return;
    }

    mapMarkers.forEach(marker => {

        if (marker) {
            marker.setMap(null);
        }

    });

    mapMarkers = [];

    buildings.forEach(building => {

        const coordinates =
            getCoordinates(building);

        if (!coordinates) return;

        const marker =
            new google.maps.Marker({

                position:
                    coordinates,

                map:
                    campusMap,

                title:
                    building.name,

                animation:
                    google.maps.Animation.DROP
            });

        const infoWindow =
            new google.maps.InfoWindow({

                content: `

                    <div style="
                        min-width:180px;
                        padding:5px;
                    ">

                        <h3 style="
                            margin:0 0 6px;
                        ">
                            🏢
                            ${escapeHTML(
                                building.name
                            )}
                        </h3>

                        <p style="
                            margin:4px 0;
                        ">
                            ${escapeHTML(
                                building.type || ""
                            )}
                        </p>

                        <small>
                            ${escapeHTML(
                                building.description || ""
                            )}
                        </small>

                    </div>
                `
            });

        marker.addListener(
            "click",
            () => {

                infoWindow.open(
                    campusMap,
                    marker
                );

            }
        );

        mapMarkers.push(marker);

    });
}


// ============================================================
// DASHBOARD
// ============================================================

function updateDashboard() {

    setText(
        "stat-buildings",
        buildings.length
    );

    setText(
        "stat-classrooms",
        classrooms.length
    );

    setText(
        "stat-food",
        foodSpots.length
    );

    setText(
        "stat-events",
        getUpcomingEvents().length
    );

    renderDashboardFood();

    renderDashboardEvents();

    updateDashboardLibrary();
}


// ============================================================
// DASHBOARD LIBRARY
// ============================================================

function updateDashboardLibrary() {

    const data =
        libraryData || {};

    const floors =
        Array.isArray(data.floors)
            ? data.floors
            : [];

    setText(
        "dashboard-library-status",
        data.status || "Unknown"
    );

    setText(
        "dashboard-library-time",
        data.timings || "Not available"
    );

    const totalSeats =
        floors.reduce(
            (sum, floor) =>
                sum +
                Number(floor.totalSeats || 0),
            0
        );

    const availableSeats =
        floors.reduce(
            (sum, floor) =>
                sum +
                Number(floor.availableSeats || 0),
            0
        );

    const occupiedSeats =
        Math.max(
            0,
            totalSeats - availableSeats
        );

    const percentage =
        totalSeats
            ? Math.round(
                occupiedSeats /
                totalSeats *
                100
            )
            : 0;

    setText(
        "dashboard-library-percent",
        `${percentage}%`
    );

    const circle =
        document.getElementById(
            "dashboard-library-circle"
        );

    if (circle) {

        circle.style.setProperty(
            "--occupancy",
            `${percentage}%`
        );
    }

    const bestFloor =
        floors.length
            ? floors.reduce(
                (best, floor) => {

                    if (!best) return floor;

                    return Number(
                        floor.availableSeats || 0
                    ) >
                    Number(
                        best.availableSeats || 0
                    )
                        ? floor
                        : best;

                },
                null
            )
            : null;

    setText(
        "dashboard-best-floor",
        bestFloor
            ? `${bestFloor.name} (${bestFloor.availableSeats} seats)`
            : "Not available"
    );
}


// ============================================================
// DASHBOARD FOOD
// ============================================================

function renderDashboardFood() {

    const container =
        document.getElementById(
            "dashboard-food"
        );

    if (!container) return;

    if (!foodSpots.length) {

        container.innerHTML = `
            <div class="empty-state">
                🍔 No food spots available.
            </div>
        `;

        return;
    }

    container.innerHTML =
        foodSpots
            .slice(0, 3)
            .map(item => `

                <div
                    class="mini-card"
                    onclick="openFoodDetails('${escapeAttribute(item.id)}')"
                    style="cursor:pointer;"
                >

                    <div class="mini-icon">
                        🍔
                    </div>

                    <div>

                        <strong>
                            ${escapeHTML(item.name)}
                        </strong>

                        <small>
                            ${escapeHTML(item.location)}
                        </small>

                    </div>

                </div>

            `)
            .join("");
}


// ============================================================
// DASHBOARD EVENTS
// ============================================================

function renderDashboardEvents() {

    const container =
        document.getElementById(
            "dashboard-events"
        );

    if (!container) return;

    const upcomingEvents =
        getUpcomingEvents();

    if (!upcomingEvents.length) {

        container.innerHTML = `
            <div class="empty-state">
                📅 No upcoming events.
            </div>
        `;

        return;
    }

    container.innerHTML =
        upcomingEvents
            .slice(0, 4)
            .map(event => `

                <div
                    class="mini-card"
                    onclick="openEventDetails('${escapeAttribute(event.id)}')"
                    style="cursor:pointer;"
                >

                    <div class="mini-icon">
                        📅
                    </div>

                    <div>

                        <strong>
                            ${escapeHTML(event.title)}
                        </strong>

                        <small>
                            ${formatDate(event.date)}
                            •
                            ${escapeHTML(event.venue || "")}
                        </small>

                    </div>

                </div>

            `)
            .join("");
}


// ============================================================
// BUILDINGS
// ============================================================

function renderBuildings() {

    const container =
        document.getElementById(
            "map-buildings"
        ) ||
        document.getElementById(
            "building-list"
        );

    if (!container) return;

    if (!buildings.length) {

        container.innerHTML = `
            <div class="empty-state">
                🏢 No buildings found.
            </div>
        `;

        return;
    }

    container.innerHTML =
        buildings
            .map(building => `

                <div
                    class="location-card"
                    onclick="openLocation('${escapeAttribute(building.name)}')"
                >

                    <div class="location-icon">
                        🏢
                    </div>

                    <div>

                        <h3>
                            ${escapeHTML(building.name)}
                        </h3>

                        <p>
                            ${escapeHTML(building.type || "")}
                        </p>

                        <small>
                            ${escapeHTML(
                                building.description || ""
                            )}
                        </small>

                    </div>

                </div>

            `)
            .join("");
}


// ============================================================
// MAP LOCATION
// ============================================================

function mapLocation(
    name,
    type = ""
) {

    showPage("map");

    setTimeout(() => {

        openLocation(name);

    }, 350);
}


// ============================================================
// OPEN LOCATION
// ============================================================

function openLocation(name) {

    const normalizedName =
        String(name || "")
            .toLowerCase()
            .replace(/\s+/g, "")
            .replace(/-/g, "");

    const building =
        buildings.find(
            item =>
                String(item.name || "")
                    .toLowerCase() ===
                String(name || "")
                    .toLowerCase()
        );

    const classroom =
        classrooms.find(item => {

            const code =
                String(item.code || "")
                    .toLowerCase()
                    .replace(/\s+/g, "")
                    .replace(/-/g, "");

            return code === normalizedName;

        });

    const result =
        document.getElementById(
            "location-result"
        );

    if (building) {

        if (result) {

            result.innerHTML = `

                <div class="location-detail">

                    <h3>
                        📍 ${escapeHTML(building.name)}
                    </h3>

                    <p>
                        ${escapeHTML(
                            building.description || ""
                        )}
                    </p>

                    <span>
                        🏢 ${escapeHTML(
                            building.type || ""
                        )}
                    </span>

                </div>

            `;
        }

        showToast(
            `📍 ${building.name}`,
            "success"
        );

        focusLocationOnMap(
            building
        );

        return;
    }

    if (classroom) {

        if (result) {

            result.innerHTML = `

                <div class="location-detail">

                    <h3>
                        🎓 ${escapeHTML(classroom.code)}
                    </h3>

                    <p>
                        ${escapeHTML(classroom.building)}
                    </p>

                    <span>
                        Floor ${escapeHTML(classroom.floor)}
                    </span>

                    <span>
                        Section:
                        ${escapeHTML(classroom.section)}
                    </span>

                    <span>
                        Capacity:
                        ${escapeHTML(classroom.capacity)}
                    </span>

                </div>

            `;
        }

        showToast(
            `📍 ${classroom.code} • ${classroom.building}`,
            "success"
        );

        focusLocationOnMap(
            classroom
        );

        return;
    }

    showToast(
        "Location not found",
        "error"
    );
}


// ============================================================
// FOCUS LOCATION ON GOOGLE MAP
// ============================================================

function focusLocationOnMap(item) {

    showSelectedLocationOnMap(
        item
    );
}


// ============================================================
// GET COORDINATES
// ============================================================

function getCoordinates(item) {

    if (!item) return null;

    if (
        isValidCoordinate(item.latitude) &&
        isValidCoordinate(item.longitude)
    ) {

        return {
            lat: Number(item.latitude),
            lng: Number(item.longitude)
        };
    }

    if (
        isValidCoordinate(item.lat) &&
        isValidCoordinate(item.lng)
    ) {

        return {
            lat: Number(item.lat),
            lng: Number(item.lng)
        };
    }

    if (
        item.coordinates &&
        isValidCoordinate(item.coordinates.lat) &&
        isValidCoordinate(item.coordinates.lng)
    ) {

        return {
            lat: Number(item.coordinates.lat),
            lng: Number(item.coordinates.lng)
        };
    }

    return null;
}


function isValidCoordinate(value) {

    return (
        value !== null &&
        value !== undefined &&
        value !== "" &&
        Number.isFinite(
            Number(value)
        )
    );
}


// ============================================================
// LOCATION SEARCH
// ============================================================

async function findLocation() {

    const input =
        document.getElementById(
            "location-search"
        );

    if (!input) return;

    const query =
        input.value.trim();

    if (!query) {

        showToast(
            "Enter a location",
            "error"
        );

        return;
    }

    const normalizedQuery =
        query
            .toLowerCase()
            .replace(/\s+/g, "")
            .replace(/-/g, "");

    const building =
        buildings.find(
            item =>
                String(item.name || "")
                    .toLowerCase()
                    .includes(
                        query.toLowerCase()
                    )
        );

    const classroom =
        classrooms.find(item => {

            const code =
                String(item.code || "")
                    .toLowerCase()
                    .replace(/\s+/g, "")
                    .replace(/-/g, "");

            const section =
                String(item.section || "")
                    .toLowerCase();

            return (
                code.includes(normalizedQuery) ||
                section.includes(
                    query.toLowerCase()
                )
            );
        });

    const food =
        foodSpots.find(item => {

            const name =
                String(item.name || "")
                    .toLowerCase();

            const location =
                String(item.location || "")
                    .toLowerCase();

            return (
                name.includes(
                    query.toLowerCase()
                ) ||
                location.includes(
                    query.toLowerCase()
                )
            );
        });

    if (building) {

        openLocation(
            building.name
        );

        return;
    }

    if (classroom) {

        openLocation(
            classroom.code
        );

        return;
    }

    if (food) {

        showPage("food");

        openFoodDetails(
            food.id
        );

        return;
    }

    const result =
        await api(
            "/search?q=" +
            encodeURIComponent(query)
        );

    if (!result) return;

    const results =
        result.data || [];

    if (!results.length) {

        showToast(
            "Location not found",
            "error"
        );

        return;
    }

    const location =
        results.find(
            item =>
                item.type === "Building" ||
                item.type === "Classroom"
        );

    if (!location) {

        showToast(
            "Location not found",
            "error"
        );

        return;
    }

    openLocation(
        location.title
    );
}


// ============================================================
// FOOD
// ============================================================

function renderFood() {

    const container =
        document.getElementById(
            "food-list"
        ) ||
        document.getElementById(
            "food-grid"
        );

    if (!container) return;

    if (!foodSpots.length) {

        container.innerHTML = `
            <div class="loading-card">
                🍔 No food spots available.
            </div>
        `;

        return;
    }

    container.innerHTML =
        foodSpots
            .map(item => `

                <div
                    class="food-card"
                    onclick="openFoodDetails('${escapeAttribute(item.id)}')"
                    style="cursor:pointer;"
                    title="Click to view complete details"
                >

                    <div class="food-image">
                        🍔
                    </div>

                    <div class="food-content">

                        <h3>
                            ${escapeHTML(item.name)}
                        </h3>

                        <p>
                            📍 ${escapeHTML(
                                item.location ||
                                "Location unavailable"
                            )}
                        </p>

                        <p>
                            ⏰ ${escapeHTML(
                                item.timings ||
                                "Timing unavailable"
                            )}
                        </p>

                        <span class="status-badge">

                            ${
                                String(
                                    item.status || ""
                                ).toLowerCase() === "open"
                                    ? "🟢"
                                    : "🔴"
                            }

                            ${escapeHTML(
                                item.status ||
                                "Unknown"
                            )}

                        </span>

                        <div class="food-menu">

                            ${
                                Array.isArray(item.menu)
                                    ? item.menu
                                        .slice(0, 5)
                                        .map(
                                            menu => `
                                                <span>
                                                    ${escapeHTML(menu)}
                                                </span>
                                            `
                                        )
                                        .join("")
                                    : ""
                            }

                        </div>

                        <div style="
                            margin-top:14px;
                            font-size:13px;
                            font-weight:600;
                            color:var(--primary,#2563eb);
                        ">
                            👆 Click for complete details
                        </div>

                    </div>

                </div>

            `)
            .join("");

    loadFoodTimings();
}


// ============================================================
// CREATE FOOD MODAL
// ============================================================

function createFoodModal() {

    if (
        document.getElementById(
            "food-details-modal"
        )
    ) {
        return;
    }

    const modal =
        document.createElement("div");

    modal.id =
        "food-details-modal";

    modal.innerHTML = `

        <div
            class="food-modal-overlay"
            onclick="closeFoodDetails(event)"
            style="
                position:fixed;
                inset:0;
                z-index:10000;
                background:rgba(0,0,0,0.65);
                display:none;
                align-items:center;
                justify-content:center;
                padding:20px;
                backdrop-filter:blur(4px);
            "
        >

            <div
                class="food-modal-content"
                onclick="event.stopPropagation()"
                style="
                    width:min(620px,100%);
                    max-height:90vh;
                    overflow-y:auto;
                    background:var(--card-bg,#fff);
                    color:var(--text-color,#111827);
                    border-radius:20px;
                    box-shadow:0 25px 70px rgba(0,0,0,0.3);
                    position:relative;
                    padding:0;
                "
            >

                <button
                    onclick="closeFoodDetails()"
                    style="
                        position:absolute;
                        right:15px;
                        top:15px;
                        width:38px;
                        height:38px;
                        border:none;
                        border-radius:50%;
                        background:rgba(0,0,0,0.08);
                        cursor:pointer;
                        font-size:20px;
                        z-index:2;
                    "
                >
                    ✕
                </button>

                <div
                    id="food-details-content"
                    style="padding:30px;"
                >
                    Loading...
                </div>

            </div>

        </div>
    `;

    document.body.appendChild(
        modal
    );
}


// ============================================================
// OPEN FOOD DETAILS
// ============================================================

function openFoodDetails(foodId) {

    const item =
        foodSpots.find(
            food =>
                String(food.id) ===
                String(foodId)
        );

    if (!item) {

        showToast(
            "Food outlet not found",
            "error"
        );

        return;
    }

    createFoodModal();

    const modal =
        document.getElementById(
            "food-details-modal"
        );

    const content =
        document.getElementById(
            "food-details-content"
        );

    if (!modal || !content) return;

    const menu =
        Array.isArray(item.menu)
            ? item.menu
            : [];

    const facilities =
        Array.isArray(item.facilities)
            ? item.facilities
            : [];

    const isOpen =
        String(item.status || "")
            .toLowerCase() === "open";

    content.innerHTML = `

        <div>

            <div style="
                font-size:52px;
                margin-bottom:10px;
            ">
                🍔
            </div>

            <div style="
                display:flex;
                align-items:flex-start;
                justify-content:space-between;
                gap:15px;
                padding-right:45px;
            ">

                <div>

                    <div style="
                        font-size:12px;
                        font-weight:700;
                        letter-spacing:1px;
                        text-transform:uppercase;
                        opacity:0.65;
                        margin-bottom:5px;
                    ">
                        ${escapeHTML(
                            item.category ||
                            "Food Outlet"
                        )}
                    </div>

                    <h2 style="
                        margin:0 0 8px;
                        font-size:28px;
                    ">
                        ${escapeHTML(item.name)}
                    </h2>

                </div>

                <span style="
                    display:inline-flex;
                    align-items:center;
                    gap:5px;
                    padding:7px 12px;
                    border-radius:20px;
                    background:${
                        isOpen
                            ? "rgba(34,197,94,0.12)"
                            : "rgba(239,68,68,0.12)"
                    };
                    color:${
                        isOpen
                            ? "#16a34a"
                            : "#dc2626"
                    };
                    font-weight:700;
                    white-space:nowrap;
                ">
                    ${isOpen ? "🟢" : "🔴"}
                    ${escapeHTML(
                        item.status ||
                        "Unknown"
                    )}
                </span>

            </div>

            <div style="
                margin-top:22px;
                display:grid;
                gap:12px;
            ">

                <div class="detail-box">

                    <strong>📍 Location</strong>

                    <div>
                        ${escapeHTML(
                            item.location ||
                            "Not available"
                        )}
                    </div>

                </div>

                ${
                    item.building
                        ? `
                            <div class="detail-box">

                                <strong>🏢 Building</strong>

                                <div>
                                    ${escapeHTML(
                                        item.building
                                    )}
                                </div>

                            </div>
                        `
                        : ""
                }

                ${
                    item.floor
                        ? `
                            <div class="detail-box">

                                <strong>🏠 Floor</strong>

                                <div>
                                    ${escapeHTML(
                                        item.floor
                                    )}
                                </div>

                            </div>
                        `
                        : ""
                }

                <div class="detail-box">

                    <strong>⏰ Timings</strong>

                    <div>
                        ${escapeHTML(
                            item.timings ||
                            "Not available"
                        )}
                    </div>

                </div>

            </div>

            ${
                item.description
                    ? `
                        <div style="margin-top:22px;">

                            <h3>
                                📝 About
                            </h3>

                            <p style="
                                line-height:1.6;
                                opacity:.8;
                            ">
                                ${escapeHTML(
                                    item.description
                                )}
                            </p>

                        </div>
                    `
                    : ""
            }

            <div style="margin-top:24px;">

                <h3>
                    🍽️ Available
                </h3>

                <div style="
                    display:flex;
                    flex-wrap:wrap;
                    gap:8px;
                ">

                    ${
                        menu.length
                            ? menu
                                .map(
                                    menuItem => `
                                        <span style="
                                            padding:8px 12px;
                                            border-radius:20px;
                                            background:rgba(37,99,235,.1);
                                            color:#2563eb;
                                            font-size:13px;
                                            font-weight:600;
                                        ">
                                            ${escapeHTML(
                                                menuItem
                                            )}
                                        </span>
                                    `
                                )
                                .join("")
                            : "Menu information not available."
                    }

                </div>

            </div>

            <div style="margin-top:24px;">

                <h3>
                    🛎️ Facilities
                </h3>

                ${
                    facilities.length
                        ? `
                            <div style="
                                display:grid;
                                grid-template-columns:
                                repeat(
                                    auto-fit,
                                    minmax(150px,1fr)
                                );
                                gap:10px;
                            ">

                                ${facilities
                                    .map(
                                        facility => `
                                            <div class="detail-box">
                                                ✓
                                                ${escapeHTML(
                                                    facility
                                                )}
                                            </div>
                                        `
                                    )
                                    .join("")}

                            </div>
                        `
                        : "Facility information not available."
                }

            </div>

            <div style="
                margin-top:28px;
                display:flex;
                gap:10px;
                flex-wrap:wrap;
            ">

                <button
                    onclick="showFoodOnMap('${escapeAttribute(item.id)}')"
                    style="
                        flex:1;
                        min-width:180px;
                        padding:13px 18px;
                        border:none;
                        border-radius:10px;
                        background:#2563eb;
                        color:white;
                        cursor:pointer;
                        font-weight:700;
                    "
                >
                    🗺️ Show on Map
                </button>

                <button
                    onclick="closeFoodDetails()"
                    style="
                        padding:13px 18px;
                        border:none;
                        border-radius:10px;
                        background:rgba(127,127,127,.12);
                        cursor:pointer;
                        font-weight:700;
                    "
                >
                    Close
                </button>

            </div>

        </div>
    `;

    const overlay =
        modal.querySelector(
            ".food-modal-overlay"
        );

    if (overlay) {
        overlay.style.display = "flex";
    }

    document.body.style.overflow =
        "hidden";
}


// ============================================================
// CLOSE FOOD
// ============================================================

function closeFoodDetails(
    event = null
) {

    if (
        event &&
        event.target &&
        !event.target.classList.contains(
            "food-modal-overlay"
        )
    ) {
        return;
    }

    const modal =
        document.getElementById(
            "food-details-modal"
        );

    if (!modal) return;

    const overlay =
        modal.querySelector(
            ".food-modal-overlay"
        );

    if (overlay) {
        overlay.style.display = "none";
    }

    document.body.style.overflow = "";
}


// ============================================================
// SHOW FOOD ON MAP
// ============================================================

function showFoodOnMap(foodId) {

    const item =
        foodSpots.find(
            food =>
                String(food.id) ===
                String(foodId)
        );

    if (!item) return;

    closeFoodDetails();

    showPage("map");

    setTimeout(() => {

        focusFoodLocation(
            item
        );

    }, 400);
}


function focusFoodLocation(item) {

    if (!campusMap) {

        refreshGoogleMap();

        setTimeout(() => {

            focusFoodLocation(
                item
            );

        }, 700);

        return;
    }

    const coordinates =
        getCoordinates(item);

    if (coordinates) {

        showSelectedLocationOnMap(
            item
        );

        return;
    }

    if (item.building) {

        const building =
            buildings.find(
                buildingItem =>
                    String(
                        buildingItem.name || ""
                    ).toLowerCase() ===
                    String(
                        item.building || ""
                    ).toLowerCase()
            );

        if (building) {

            const buildingCoordinates =
                getCoordinates(
                    building
                );

            if (buildingCoordinates) {

                showSelectedLocationOnMap(
                    {
                        ...item,
                        name:
                            item.name,
                        building:
                            building.name
                    }
                );

                showToast(
                    `📍 ${item.name} • ${item.building}`,
                    "success"
                );

                return;
            }
        }
    }

    focusMapOnPIET();

    showToast(
        `${item.name} is ${item.location}. Exact coordinates are not available yet.`,
        "info"
    );
}


// ============================================================
// FOOD TIMINGS
// ============================================================

async function loadFoodTimings() {

    const result =
        await api(
            "/food/timings"
        );

    if (!result) return;

    const container =
        document.getElementById(
            "food-timings"
        );

    if (!container) return;

    const timings =
        result.data || {};

    container.innerHTML =
        Object.entries(timings)
            .map(
                ([meal, time]) => `

                    <div class="timing-card">

                        <span>🍽️</span>

                        <strong>
                            ${escapeHTML(meal)}
                        </strong>

                        <small>
                            ${escapeHTML(time)}
                        </small>

                    </div>
                `
            )
            .join("");
}


// ============================================================
// LIBRARY
// ============================================================

async function loadLibraryAvailability() {

    const result =
        await api(
            "/library/availability"
        );

    if (!result) {

        renderLibrary();

        return;
    }

    const floors =
        Array.isArray(result.data)
            ? result.data
            : [];

    libraryData = {
        ...(libraryData || {}),
        ...(result.library || {}),
        floors
    };

    renderLibrary();
}


function renderLibrary() {

    const data =
        libraryData || {};

    const floors =
        Array.isArray(data.floors)
            ? data.floors
            : [];

    setText(
        "library-status",
        data.status || "Unknown"
    );

    setText(
        "library-timings",
        data.timings || "Not available"
    );

    const totalSeats =
        floors.reduce(
            (sum, floor) =>
                sum +
                Number(
                    floor.totalSeats || 0
                ),
            0
        );

    const availableSeats =
        floors.reduce(
            (sum, floor) =>
                sum +
                Number(
                    floor.availableSeats || 0
                ),
            0
        );

    const occupiedSeats =
        Math.max(
            0,
            totalSeats -
            availableSeats
        );

    const percentage =
        totalSeats
            ? Math.round(
                occupiedSeats /
                totalSeats *
                100
            )
            : 0;

    setText(
        "library-percent",
        `${percentage}%`
    );

    setText(
        "library-floors",
        floors.length
    );

    setText(
        "library-total-seats",
        totalSeats
    );

    setText(
        "library-available-seats",
        availableSeats
    );

    const container =
        document.getElementById(
            "library-floors-grid"
        ) ||
        document.getElementById(
            "library-floors"
        );

    if (!container) return;

    if (!floors.length) {

        container.innerHTML = `
            <div class="empty-state">
                📚 Library floor data unavailable.
            </div>
        `;

        return;
    }

    container.innerHTML =
        floors
            .map(floor => {

                const total =
                    Number(
                        floor.totalSeats || 0
                    );

                const available =
                    Number(
                        floor.availableSeats || 0
                    );

                const occupied =
                    Number(
                        floor.occupiedSeats ??
                        Math.max(
                            0,
                            total - available
                        )
                    );

                const floorPercentage =
                    Number(
                        floor.occupancyPercentage ??
                        (
                            total > 0
                                ? Math.round(
                                    occupied /
                                    total *
                                    100
                                )
                                : 0
                        )
                    );

                return `

                    <div
                        class="floor-card"
                        onclick="openLibraryFloor('${escapeAttribute(floor.name)}')"
                        style="
                            cursor:pointer;
                            transition:transform .2s ease;
                        "
                        title="Click to view floor details"
                    >

                        <div class="floor-header">

                            <div>

                                <strong>
                                    📚 ${escapeHTML(
                                        floor.name
                                    )}
                                </strong>

                                <span class="floor-status">
                                    ${escapeHTML(
                                        floor.status ||
                                        "Unknown"
                                    )}
                                </span>

                            </div>

                            <span class="floor-available">
                                ${available} seats free
                            </span>

                        </div>

                        <div class="progress-bar">

                            <div
                                class="progress-fill"
                                style="
                                    width:${floorPercentage}%;
                                "
                            ></div>

                        </div>

                        <div class="floor-footer">

                            <small>
                                ${occupied}
                                occupied /
                                ${total}
                                total
                            </small>

                            <small>
                                ${floorPercentage}%
                                occupied
                            </small>

                        </div>

                        <div style="
                            margin-top:10px;
                            font-size:12px;
                            font-weight:700;
                            color:var(--primary,#2563eb);
                        ">
                            👆 Click for floor details
                        </div>

                    </div>
                `;
            })
            .join("");
}


// ============================================================
// LIBRARY FLOOR MODAL
// ============================================================

function createLibraryModal() {

    if (
        document.getElementById(
            "library-floor-modal"
        )
    ) {
        return;
    }

    const modal =
        document.createElement("div");

    modal.id =
        "library-floor-modal";

    modal.innerHTML = `

        <div
            class="library-modal-overlay"
            onclick="closeLibraryFloor(event)"
            style="
                position:fixed;
                inset:0;
                z-index:10001;
                background:rgba(0,0,0,.65);
                display:none;
                align-items:center;
                justify-content:center;
                padding:20px;
                backdrop-filter:blur(4px);
            "
        >

            <div
                onclick="event.stopPropagation()"
                style="
                    width:min(600px,100%);
                    max-height:90vh;
                    overflow:auto;
                    background:var(--card-bg,#fff);
                    color:var(--text-color,#111827);
                    border-radius:22px;
                    box-shadow:0 25px 70px rgba(0,0,0,.35);
                    position:relative;
                    padding:30px;
                "
            >

                <button
                    onclick="closeLibraryFloor()"
                    style="
                        position:absolute;
                        right:15px;
                        top:15px;
                        width:38px;
                        height:38px;
                        border:none;
                        border-radius:50%;
                        cursor:pointer;
                        font-size:20px;
                    "
                >
                    ✕
                </button>

                <div id="library-floor-content">
                    Loading...
                </div>

            </div>

        </div>
    `;

    document.body.appendChild(
        modal
    );
}


// ============================================================
// OPEN LIBRARY FLOOR
// ============================================================

async function openLibraryFloor(
    floorName
) {

    createLibraryModal();

    const modal =
        document.getElementById(
            "library-floor-modal"
        );

    const content =
        document.getElementById(
            "library-floor-content"
        );

    if (!modal || !content) return;

    const overlay =
        modal.querySelector(
            ".library-modal-overlay"
        );

    if (overlay) {
        overlay.style.display = "flex";
    }

    document.body.style.overflow =
        "hidden";

    content.innerHTML = `
        <div style="
            text-align:center;
            padding:30px;
        ">
            📚 Loading ${escapeHTML(floorName)}...
        </div>
    `;

    const result =
        await api(
            "/library/floor/" +
            encodeURIComponent(floorName)
        );

    if (
        !result ||
        !result.data
    ) {

        const floor =
            libraryData.floors?.find(
                item =>
                    String(item.name)
                        .toLowerCase() ===
                    String(floorName)
                        .toLowerCase()
            );

        if (floor) {

            renderLibraryFloorDetails(
                floor
            );

        } else {

            content.innerHTML = `
                <div class="empty-state">
                    ❌ Floor information not available.
                </div>
            `;
        }

        return;
    }

    renderLibraryFloorDetails(
        result.data
    );
}


// ============================================================
// RENDER LIBRARY FLOOR DETAILS
// ============================================================

function renderLibraryFloorDetails(
    floor
) {

    const content =
        document.getElementById(
            "library-floor-content"
        );

    if (!content) return;

    const total =
        Number(
            floor.totalSeats || 0
        );

    const available =
        Number(
            floor.availableSeats || 0
        );

    const occupied =
        Number(
            floor.occupiedSeats ??
            Math.max(
                0,
                total - available
            )
        );

    const percentage =
        Number(
            floor.occupancyPercentage ??
            (
                total
                    ? Math.round(
                        occupied /
                        total *
                        100
                    )
                    : 0
            )
        );

    content.innerHTML = `

        <div>

            <div style="
                font-size:50px;
                margin-bottom:10px;
            ">
                📚
            </div>

            <div style="
                padding-right:45px;
            ">

                <div style="
                    font-size:12px;
                    font-weight:700;
                    letter-spacing:1px;
                    text-transform:uppercase;
                    opacity:.6;
                ">
                    CENTRAL LIBRARY
                </div>

                <h2 style="
                    margin:5px 0;
                    font-size:28px;
                ">
                    ${escapeHTML(floor.name)}
                </h2>

                <span style="
                    display:inline-block;
                    margin-top:8px;
                    padding:7px 13px;
                    border-radius:20px;
                    background:rgba(37,99,235,.1);
                    color:#2563eb;
                    font-weight:700;
                ">
                    ${escapeHTML(
                        floor.status ||
                        "Unknown"
                    )}
                </span>

            </div>

            <div style="
                margin-top:25px;
                display:grid;
                grid-template-columns:
                repeat(
                    auto-fit,
                    minmax(130px,1fr)
                );
                gap:12px;
            ">

                <div class="detail-box">

                    <div style="
                        font-size:26px;
                        font-weight:800;
                    ">
                        ${total}
                    </div>

                    <small>
                        Total Seats
                    </small>

                </div>

                <div class="detail-box">

                    <div style="
                        font-size:26px;
                        font-weight:800;
                        color:#16a34a;
                    ">
                        ${available}
                    </div>

                    <small>
                        Available
                    </small>

                </div>

                <div class="detail-box">

                    <div style="
                        font-size:26px;
                        font-weight:800;
                    ">
                        ${occupied}
                    </div>

                    <small>
                        Occupied
                    </small>

                </div>

            </div>

            <div style="
                margin-top:25px;
            ">

                <div style="
                    display:flex;
                    justify-content:space-between;
                    margin-bottom:8px;
                    font-weight:700;
                ">

                    <span>
                        Seat Occupancy
                    </span>

                    <span>
                        ${percentage}%
                    </span>

                </div>

                <div style="
                    height:12px;
                    background:rgba(127,127,127,.15);
                    border-radius:20px;
                    overflow:hidden;
                ">

                    <div style="
                        width:${percentage}%;
                        height:100%;
                        background:#2563eb;
                        border-radius:20px;
                    "></div>

                </div>

            </div>

            <div style="
                margin-top:22px;
            ">

                <div class="detail-box">

                    <strong>
                        📊 Current Availability
                    </strong>

                    <p style="
                        margin:8px 0 0;
                        line-height:1.6;
                        opacity:.8;
                    ">
                        ${available} seats are currently
                        available out of ${total} total
                        seats on this floor.
                    </p>

                </div>

            </div>

            <div style="
                margin-top:20px;
            ">

                <div class="detail-box">

                    <strong>
                        ⏰ Library Timings
                    </strong>

                    <p style="
                        margin:7px 0 0;
                    ">
                        ${escapeHTML(
                            libraryData.timings ||
                            "8:00 AM - 10:00 PM"
                        )}
                    </p>

                </div>

            </div>

        </div>
    `;
}


// ============================================================
// CLOSE LIBRARY MODAL
// ============================================================

function closeLibraryFloor(
    event = null
) {

    if (
        event &&
        event.target &&
        !event.target.classList.contains(
            "library-modal-overlay"
        )
    ) {
        return;
    }

    const modal =
        document.getElementById(
            "library-floor-modal"
        );

    if (!modal) return;

    const overlay =
        modal.querySelector(
            ".library-modal-overlay"
        );

    if (overlay) {
        overlay.style.display = "none";
    }

    document.body.style.overflow = "";
}


// ============================================================
// EVENTS
// ============================================================

function getUpcomingEvents() {

    const today =
        new Date();

    today.setHours(
        0,
        0,
        0,
        0
    );

    return events
        .filter(event => {

            const eventDate =
                new Date(event.date);

            return (
                !Number.isNaN(
                    eventDate.getTime()
                ) &&
                eventDate >= today
            );

        })
        .sort(
            (a, b) =>
                new Date(a.date) -
                new Date(b.date)
        );
}


function renderEvents() {

    const container =
        document.getElementById(
            "events-list"
        ) ||
        document.getElementById(
            "events-grid"
        );

    if (!container) return;

    const upcomingEvents =
        getUpcomingEvents();

    if (!upcomingEvents.length) {

        container.innerHTML = `
            <div class="empty-state">
                📅 No upcoming events.
            </div>
        `;

        return;
    }

    container.innerHTML =
        upcomingEvents
            .map(event => `

                <div
                    class="event-card"
                    onclick="openEventDetails('${escapeAttribute(event.id)}')"
                    style="
                        cursor:pointer;
                    "
                    title="Click to view complete event details"
                >

                    <div class="event-date">

                        <strong>
                            ${formatDate(event.date)}
                        </strong>

                    </div>

                    <div class="event-content">

                        <span class="event-category">
                            ${escapeHTML(
                                event.category ||
                                "Event"
                            )}
                        </span>

                        <h3>
                            ${escapeHTML(
                                event.title
                            )}
                        </h3>

                        <p>
                            ${escapeHTML(
                                event.description ||
                                ""
                            )}
                        </p>

                        <div class="event-meta">

                            <span>
                                🕐 ${escapeHTML(
                                    event.time || ""
                                )}
                            </span>

                            <span>
                                📍 ${escapeHTML(
                                    event.venue || ""
                                )}
                            </span>

                        </div>

                        <div style="
                            margin-top:10px;
                            font-size:12px;
                            font-weight:700;
                            color:var(--primary,#2563eb);
                        ">
                            👆 Click for complete details
                        </div>

                    </div>

                </div>

            `)
            .join("");
}


// ============================================================
// CREATE EVENT MODAL
// ============================================================

function createEventModal() {

    if (
        document.getElementById(
            "event-details-modal"
        )
    ) {
        return;
    }

    const modal =
        document.createElement("div");

    modal.id =
        "event-details-modal";

    modal.innerHTML = `

        <div
            class="event-modal-overlay"
            onclick="closeEventDetails(event)"
            style="
                position:fixed;
                inset:0;
                z-index:10002;
                background:rgba(0,0,0,.65);
                display:none;
                align-items:center;
                justify-content:center;
                padding:20px;
                backdrop-filter:blur(4px);
            "
        >

            <div
                onclick="event.stopPropagation()"
                style="
                    width:min(650px,100%);
                    max-height:90vh;
                    overflow-y:auto;
                    background:var(--card-bg,#fff);
                    color:var(--text-color,#111827);
                    border-radius:22px;
                    box-shadow:0 25px 70px rgba(0,0,0,.35);
                    position:relative;
                    padding:30px;
                "
            >

                <button
                    onclick="closeEventDetails()"
                    style="
                        position:absolute;
                        right:15px;
                        top:15px;
                        width:38px;
                        height:38px;
                        border:none;
                        border-radius:50%;
                        cursor:pointer;
                        font-size:20px;
                    "
                >
                    ✕
                </button>

                <div id="event-details-content">
                    Loading...
                </div>

            </div>

        </div>
    `;

    document.body.appendChild(
        modal
    );
}


// ============================================================
// OPEN EVENT DETAILS
// ============================================================

async function openEventDetails(
    eventId
) {

    createEventModal();

    const modal =
        document.getElementById(
            "event-details-modal"
        );

    const content =
        document.getElementById(
            "event-details-content"
        );

    if (!modal || !content) return;

    const overlay =
        modal.querySelector(
            ".event-modal-overlay"
        );

    if (overlay) {
        overlay.style.display = "flex";
    }

    document.body.style.overflow =
        "hidden";

    content.innerHTML = `
        <div style="
            text-align:center;
            padding:30px;
        ">
            📅 Loading event details...
        </div>
    `;

    const result =
        await api(
            "/events/" +
            encodeURIComponent(eventId)
        );

    let event =
        result?.data || null;

    if (!event) {

        event =
            events.find(
                item =>
                    String(item.id) ===
                    String(eventId)
            );
    }

    if (!event) {

        content.innerHTML = `
            <div class="empty-state">
                ❌ Event information not available.
            </div>
        `;

        return;
    }

    renderEventDetails(
        event
    );
}


// ============================================================
// RENDER EVENT DETAILS
// ============================================================

function renderEventDetails(
    event
) {

    const content =
        document.getElementById(
            "event-details-content"
        );

    if (!content) return;

    const status =
        String(
            event.status || "Upcoming"
        );

    const statusLower =
        status.toLowerCase();

    const isCompleted =
        statusLower === "completed";

    content.innerHTML = `

        <div>

            <div style="
                font-size:52px;
                margin-bottom:10px;
            ">
                📅
            </div>

            <div style="
                padding-right:45px;
            ">

                <div style="
                    font-size:12px;
                    font-weight:700;
                    letter-spacing:1px;
                    text-transform:uppercase;
                    opacity:.6;
                ">
                    ${escapeHTML(
                        event.category ||
                        "Campus Event"
                    )}
                </div>

                <h2 style="
                    margin:5px 0 10px;
                    font-size:28px;
                    line-height:1.25;
                ">
                    ${escapeHTML(
                        event.title
                    )}
                </h2>

                <span style="
                    display:inline-block;
                    padding:7px 13px;
                    border-radius:20px;
                    background:${
                        isCompleted
                            ? "rgba(107,114,128,.12)"
                            : "rgba(34,197,94,.12)"
                    };
                    color:${
                        isCompleted
                            ? "#6b7280"
                            : "#16a34a"
                    };
                    font-weight:700;
                ">
                    ${
                        isCompleted
                            ? "✓"
                            : "🟢"
                    }
                    ${escapeHTML(status)}
                </span>

            </div>

            <div style="
                margin-top:25px;
                display:grid;
                gap:12px;
            ">

                <div class="detail-box">

                    <strong>
                        📅 Date
                    </strong>

                    <div>
                        ${formatDate(event.date)}
                    </div>

                </div>

                <div class="detail-box">

                    <strong>
                        🕐 Time
                    </strong>

                    <div>
                        ${escapeHTML(
                            event.time ||
                            "Not available"
                        )}
                    </div>

                </div>

                ${
                    event.duration
                        ? `
                            <div class="detail-box">

                                <strong>
                                    ⏱️ Duration
                                </strong>

                                <div>
                                    ${escapeHTML(
                                        event.duration
                                    )}
                                </div>

                            </div>
                        `
                        : ""
                }

                <div class="detail-box">

                    <strong>
                        📍 Venue
                    </strong>

                    <div>
                        ${escapeHTML(
                            event.venue ||
                            "Not available"
                        )}
                    </div>

                </div>

                ${
                    event.organizer
                        ? `
                            <div class="detail-box">

                                <strong>
                                    👥 Organizer
                                </strong>

                                <div>
                                    ${escapeHTML(
                                        event.organizer
                                    )}
                                </div>

                            </div>
                        `
                        : ""
                }

                ${
                    event.eligibility
                        ? `
                            <div class="detail-box">

                                <strong>
                                    🎓 Eligibility
                                </strong>

                                <div>
                                    ${escapeHTML(
                                        event.eligibility
                                    )}
                                </div>

                            </div>
                        `
                        : ""
                }

                ${
                    event.registration
                        ? `
                            <div class="detail-box">

                                <strong>
                                    📝 Registration
                                </strong>

                                <div>
                                    ${escapeHTML(
                                        event.registration
                                    )}
                                </div>

                            </div>
                        `
                        : ""
                }

            </div>

            ${
                event.description
                    ? `
                        <div style="
                            margin-top:25px;
                        ">

                            <h3>
                                📝 About Event
                            </h3>

                            <p style="
                                line-height:1.7;
                                opacity:.8;
                            ">
                                ${escapeHTML(
                                    event.description
                                )}
                            </p>

                        </div>
                    `
                    : ""
            }

            <div style="
                margin-top:28px;
            ">

                <button
                    onclick="closeEventDetails()"
                    style="
                        width:100%;
                        padding:13px 18px;
                        border:none;
                        border-radius:10px;
                        background:#2563eb;
                        color:white;
                        cursor:pointer;
                        font-weight:700;
                        font-size:14px;
                    "
                >
                    Close
                </button>

            </div>

        </div>
    `;
}


// ============================================================
// CLOSE EVENT MODAL
// ============================================================

function closeEventDetails(
    event = null
) {

    if (
        event &&
        event.target &&
        !event.target.classList.contains(
            "event-modal-overlay"
        )
    ) {
        return;
    }

    const modal =
        document.getElementById(
            "event-details-modal"
        );

    if (!modal) return;

    const overlay =
        modal.querySelector(
            ".event-modal-overlay"
        );

    if (overlay) {
        overlay.style.display = "none";
    }

    document.body.style.overflow = "";
}


// ============================================================
// ANNOUNCEMENTS
// ============================================================

async function loadAnnouncements() {

    const result =
        await api(
            "/announcements"
        );

    if (!result) return;

    announcements =
        Array.isArray(result.data)
            ? result.data
            : [];

    renderAnnouncements(
        "dashboard-announcements"
    );

    renderAnnouncements(
        "announcements-page"
    );
}


function renderAnnouncements(
    containerId
) {

    const container =
        document.getElementById(
            containerId
        );

    if (!container) return;

    if (!announcements.length) {

        container.innerHTML = `
            <div class="empty-state">
                📢 No announcements available.
            </div>
        `;

        return;
    }

    container.innerHTML =
        announcements
            .map(item => `

                <div class="announcement-card">

                    <div class="announcement-icon">

                        ${
                            item.priority === "High"
                                ? "🚨"
                                : "📢"
                        }

                    </div>

                    <div>

                        <div class="announcement-top">

                            <strong>
                                ${escapeHTML(
                                    item.title
                                )}
                            </strong>

                            <span>
                                ${escapeHTML(
                                    item.priority ||
                                    "Normal"
                                )}
                            </span>

                        </div>

                        <p>
                            ${escapeHTML(
                                item.message || ""
                            )}
                        </p>

                        <small>
                            ${escapeHTML(
                                item.date || ""
                            )}
                        </small>

                    </div>

                </div>

            `)
            .join("");
}


// ============================================================
// ACADEMICS
// ============================================================

function renderAcademics() {

    renderClassrooms();

    renderDepartments();
}


function renderClassrooms(
    list = classrooms
) {

    const container =
        document.getElementById(
            "classrooms-list"
        ) ||
        document.getElementById(
            "classroom-results"
        );

    if (!container) return;

    if (
        !Array.isArray(list) ||
        !list.length
    ) {

        container.innerHTML = `
            <div class="empty-state">
                ❌ No classrooms found.
            </div>
        `;

        return;
    }

    container.innerHTML =
        list
            .map(item => `

                <div
                    class="classroom-card"
                    onclick="openLocation('${escapeAttribute(item.code)}')"
                >

                    <div class="classroom-icon">
                        🏫
                    </div>

                    <div>

                        <h3>
                            ${escapeHTML(item.code)}
                        </h3>

                        <p>
                            ${escapeHTML(
                                item.building
                            )}
                            • Floor
                            ${escapeHTML(item.floor)}
                        </p>

                        <p>
                            🎓 ${escapeHTML(
                                item.section
                            )}
                        </p>

                        <small>
                            👥 Capacity:
                            ${escapeHTML(
                                item.capacity
                            )}
                            •
                            ${escapeHTML(
                                item.type
                            )}
                        </small>

                    </div>

                </div>

            `)
            .join("");
}


async function searchClassrooms() {

    const input =
        document.getElementById(
            "classroom-search"
        );

    if (!input) return;

    const query =
        input.value.trim();

    if (!query) {

        renderClassrooms();

        return;
    }

    const result =
        await api(
            "/classrooms/search?q=" +
            encodeURIComponent(query)
        );

    if (!result) return;

    renderClassrooms(
        Array.isArray(result.data)
            ? result.data
            : []
    );
}


// ============================================================
// DEPARTMENTS
// ============================================================

function renderDepartments() {

    const container =
        document.getElementById(
            "departments-list"
        ) ||
        document.getElementById(
            "departments-grid"
        );

    if (!container) return;

    if (!departments.length) {

        container.innerHTML = `
            <div class="empty-state">
                🎓 No departments found.
            </div>
        `;

        return;
    }

    container.innerHTML =
        departments
            .map(dept => `

                <div class="department-card">

                    <div class="department-icon">
                        🎓
                    </div>

                    <div>

                        <h3>
                            ${escapeHTML(
                                dept.name
                            )}
                        </h3>

                        <p>
                            ${escapeHTML(
                                dept.shortName
                            )}
                        </p>

                        <small>
                            📍 ${escapeHTML(
                                dept.building
                            )}
                            • Floor
                            ${escapeHTML(
                                dept.floor
                            )}
                        </small>

                    </div>

                </div>

            `)
            .join("");
}


// ============================================================
// AI ASSISTANT
// ============================================================

function setupAI() {

    const input =
        document.getElementById(
            "ai-input"
        );

    if (!input) return;

    if (
        input.dataset.ready === "true"
    ) {
        return;
    }

    input.dataset.ready = "true";
}


function handleAIKey(event) {

    if (
        event.key === "Enter" &&
        !event.shiftKey
    ) {

        event.preventDefault();

        sendAIMessage();
    }
}


async function sendAIMessage() {

    const input =
        document.getElementById(
            "ai-input"
        );

    if (!input) return;

    const message =
        input.value.trim();

    if (!message) return;

    addUserMessage(
        message
    );

    input.value = "";

    const typingId =
        addTypingMessage();

    try {

        const result =
            await api(
                "/ai/ask",
                {

                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify({
                            question: message
                        })
                }
            );

        removeTypingMessage(
            typingId
        );

        if (!result) {

            addAIMessage(
                "❌ I couldn't connect to the Campus Helper AI service."
            );

            return;
        }

        const answer =
            result.answer ||
            result.reply ||
            result.response;

        if (answer) {

            addAIMessage(
                answer
            );

        } else {

            addAIMessage(
                "🤖 No response generated."
            );
        }

        if (
            Array.isArray(result.results) &&
            result.results.length
        ) {

            addAIResults(
                result.results
            );
        }

        if (
            Array.isArray(
                result.suggestions
            )
        ) {

            addAISuggestions(
                result.suggestions
            );
        }

    } catch (error) {

        console.error(
            "AI Assistant Error:",
            error
        );

        removeTypingMessage(
            typingId
        );

        addAIMessage(
            "❌ Something went wrong while processing your question."
        );
    }
}


function askAI(message) {

    const input =
        document.getElementById(
            "ai-input"
        );

    if (!input) return;

    showPage(
        "assistant"
    );

    input.value =
        message;

    sendAIMessage();
}


function getAIChatContainer() {

    const ids = [
        "chat-messages",
        "ai-chat",
        "ai-messages",
        "chat-container"
    ];

    for (
        const id of ids
    ) {

        const element =
            document.getElementById(
                id
            );

        if (element) return element;
    }

    return null;
}


function addUserMessage(
    message
) {

    const container =
        getAIChatContainer();

    if (!container) return;

    const element =
        document.createElement(
            "div"
        );

    element.className =
        "chat-message user-message";

    element.innerHTML = `

        <div class="message-avatar">
            👤
        </div>

        <div class="message-content">

            <div class="message-bubble">
                ${escapeHTML(message)}
            </div>

        </div>
    `;

    container.appendChild(
        element
    );

    scrollAIChat();
}


function addAIMessage(
    message
) {

    const container =
        getAIChatContainer();

    if (!container) return;

    const element =
        document.createElement(
            "div"
        );

    element.className =
        "chat-message ai-message";

    element.innerHTML = `

        <div class="message-avatar">
            🤖
        </div>

        <div class="message-content">

            <div class="message-bubble">
                ${formatAIText(message)}
            </div>

        </div>
    `;

    container.appendChild(
        element
    );

    scrollAIChat();
}


function addAIResults(
    results
) {

    const container =
        getAIChatContainer();

    if (!container) return;

    const wrapper =
        document.createElement(
            "div"
        );

    wrapper.className =
        "ai-results";

    results
        .slice(0, 5)
        .forEach(result => {

            const card =
                document.createElement(
                    "div"
                );

            card.className =
                "ai-result-card";

            const item =
                result.item || {};

            let details = "";

            Object.entries(item)
                .forEach(
                    ([key, value]) => {

                        if (
                            value !== null &&
                            value !== undefined &&
                            typeof value !== "object"
                        ) {

                            details += `

                                <div>

                                    <strong>
                                        ${escapeHTML(key)}
                                    </strong>:

                                    ${escapeHTML(value)}

                                </div>
                            `;
                        }
                    }
                );

            card.innerHTML = `

                <div class="ai-result-category">
                    ${escapeHTML(
                        result.category ||
                        "Result"
                    )}
                </div>

                <div class="ai-result-details">
                    ${details}
                </div>
            `;

            wrapper.appendChild(
                card
            );
        });

    container.appendChild(
        wrapper
    );

    scrollAIChat();
}


function addTypingMessage() {

    const container =
        getAIChatContainer();

    if (!container) return null;

    const id =
        `typing-${Date.now()}`;

    const element =
        document.createElement(
            "div"
        );

    element.id =
        id;

    element.className =
        "chat-message ai-message";

    element.innerHTML = `

        <div class="message-avatar">
            🤖
        </div>

        <div class="message-content">

            <div class="message-bubble typing">

                <span></span>
                <span></span>
                <span></span>

            </div>

        </div>
    `;

    container.appendChild(
        element
    );

    scrollAIChat();

    return id;
}


function removeTypingMessage(
    id
) {

    if (!id) return;

    const element =
        document.getElementById(
            id
        );

    if (element) {
        element.remove();
    }
}


function addAISuggestions(
    suggestions
) {

    const container =
        getAIChatContainer();

    if (!container) return;

    const wrapper =
        document.createElement(
            "div"
        );

    wrapper.className =
        "ai-suggestions";

    suggestions.forEach(
        suggestion => {

            const button =
                document.createElement(
                    "button"
                );

            button.className =
                "suggestion-btn";

            button.textContent =
                suggestion;

            button.onclick =
                () =>
                    askAI(
                        suggestion
                    );

            wrapper.appendChild(
                button
            );
        }
    );

    container.appendChild(
        wrapper
    );

    scrollAIChat();
}


function scrollAIChat() {

    const container =
        getAIChatContainer();

    if (!container) return;

    setTimeout(() => {

        container.scrollTop =
            container.scrollHeight;

    }, 50);
}


function formatAIText(
    text
) {

    return escapeHTML(
        String(text ?? "")
    )
        .replace(
            /\*\*(.*?)\*\*/g,
            "<strong>$1</strong>"
        )
        .replace(
            /\n/g,
            "<br>"
        );
}


// ============================================================
// GLOBAL SEARCH
// ============================================================

function setupGlobalSearch() {

    const input =
        document.getElementById(
            "global-search"
        );

    if (!input) return;

    if (
        input.dataset.ready === "true"
    ) {
        return;
    }

    input.dataset.ready = "true";

    input.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Enter"
            ) {

                event.preventDefault();

                performGlobalSearch(
                    input.value
                );
            }
        }
    );
}


function globalSearch() {

    const input =
        document.getElementById(
            "global-search"
        );

    if (!input) return;

    const query =
        input.value.trim();

    if (!query) {

        const panel =
            document.getElementById(
                "global-search-results"
            );

        if (panel) {
            panel.remove();
        }

        return;
    }

    performGlobalSearch(
        query
    );
}


async function performGlobalSearch(
    query
) {

    query =
        String(query || "").trim();

    if (!query) return;

    const result =
        await api(
            "/search?q=" +
            encodeURIComponent(query)
        );

    if (!result) return;

    showSearchResults(
        result.data || [],
        query
    );
}


function showSearchResults(
    results,
    query
) {

    const old =
        document.getElementById(
            "global-search-results"
        );

    if (old) {
        old.remove();
    }

    const panel =
        document.createElement(
            "div"
        );

    panel.id =
        "global-search-results";

    panel.className =
        "search-results-panel";

    panel.innerHTML = `

        <div class="search-results-header">

            <strong>
                🔎 Results for "${escapeHTML(query)}"
            </strong>

            <button
                onclick="
                    this.closest(
                        '.search-results-panel'
                    ).remove()
                "
            >
                ✕
            </button>

        </div>

        <div class="search-results-body">

            ${
                results.length
                    ? results
                        .map(
                            item => `

                                <div
                                    class="search-result-item"
                                    onclick="
                                        handleSearchResult(
                                            '${escapeAttribute(
                                                item.type
                                            )}',
                                            '${escapeAttribute(
                                                item.title
                                            )}'
                                        )
                                    "
                                >

                                    <span class="result-type">
                                        ${escapeHTML(
                                            item.type
                                        )}
                                    </span>

                                    <strong>
                                        ${escapeHTML(
                                            item.title
                                        )}
                                    </strong>

                                    <small>
                                        ${escapeHTML(
                                            item.description ||
                                            ""
                                        )}
                                    </small>

                                </div>
                            `
                        )
                        .join("")
                    : `
                        <div class="empty-state">
                            ❌ No results found.
                        </div>
                    `
            }

        </div>
    `;

    document.body.appendChild(
        panel
    );
}


// ============================================================
// HANDLE SEARCH RESULT
// ============================================================

function handleSearchResult(
    type,
    title
) {

    if (
        type === "Building"
    ) {

        showPage(
            "map"
        );

        setTimeout(() => {

            openLocation(
                title
            );

        }, 300);
    }

    else if (
        type === "Classroom"
    ) {

        showPage(
            "academics"
        );

        const input =
            document.getElementById(
                "classroom-search"
            );

        if (input) {

            input.value =
                title;

            searchClassrooms();
        }
    }

    else if (
        type === "Food"
    ) {

        showPage(
            "food"
        );

        const food =
            foodSpots.find(
                item =>
                    String(
                        item.name || ""
                    )
                        .toLowerCase() ===
                    String(
                        title || ""
                    )
                        .toLowerCase()
            );

        if (food) {

            setTimeout(() => {

                openFoodDetails(
                    food.id
                );

            }, 250);
        }
    }

    else if (
        type === "Event"
    ) {

        showPage(
            "events"
        );

        const event =
            events.find(
                item =>
                    String(
                        item.title || ""
                    )
                        .toLowerCase() ===
                    String(
                        title || ""
                    )
                        .toLowerCase()
            );

        if (event) {

            setTimeout(() => {

                openEventDetails(
                    event.id
                );

            }, 250);
        }
    }

    else if (
        type === "Department"
    ) {

        showPage(
            "academics"
        );
    }

    else if (
        type === "Announcement"
    ) {

        showPage(
            "events"
        );
    }

    else if (
        type === "Library"
    ) {

        showPage(
            "library"
        );

    }

    else {

        showToast(
            `${title}`,
            "info"
        );
    }

    const panel =
        document.getElementById(
            "global-search-results"
        );

    if (panel) {
        panel.remove();
    }
}


// ============================================================
// COMPLAINTS
// ============================================================

function setupComplaintForm() {

    const form =
        document.getElementById(
            "complaint-form"
        );

    if (!form) return;

    if (
        form.dataset.ready === "true"
    ) {
        return;
    }

    form.dataset.ready = "true";
}


async function submitComplaint(
    event
) {

    event.preventDefault();

    const title =
        getValue(
            "complaint-title"
        ).trim();

    const category =
        getValue(
            "complaint-category"
        ) ||
        "General";

    const description =
        getValue(
            "complaint-description"
        ).trim();

    const location =
        getValue(
            "complaint-location"
        ).trim() ||
        "Not specified";

    const priority =
        getValue(
            "complaint-priority"
        ) ||
        "Medium";

    if (
        !title ||
        !description
    ) {

        showToast(
            "Title and description are required",
            "error"
        );

        return;
    }

    const result =
        await api(
            "/complaints",
            {

                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body:
                    JSON.stringify({
                        title,
                        category,
                        description,
                        location,
                        priority
                    })
            }
        );

    if (!result) return;

    showToast(
        `Complaint ${
            result.data?.id || ""
        } submitted successfully`,
        "success"
    );

    const form =
        document.getElementById(
            "complaint-form"
        );

    if (form) {
        form.reset();
    }

    await loadComplaints();
}


async function loadComplaints() {

    const result =
        await api(
            "/complaints"
        );

    if (!result) return;

    complaints =
        Array.isArray(result.data)
            ? result.data
            : [];

    const container =
        document.getElementById(
            "complaints-list"
        ) ||
        document.getElementById(
            "recent-complaints"
        );

    if (!container) return;

    if (!complaints.length) {

        container.innerHTML = `
            <div class="empty-state">
                🎫 No complaints submitted yet.
            </div>
        `;

        return;
    }

    container.innerHTML =
        complaints
            .slice()
            .reverse()
            .map(item => `

                <div class="complaint-card">

                    <div>

                        <strong>
                            ${escapeHTML(
                                item.title
                            )}
                        </strong>

                        <p>
                            ${escapeHTML(
                                item.description
                            )}
                        </p>

                        <small>
                            🎫 ${escapeHTML(item.id)}
                            •
                            ${escapeHTML(item.status)}
                            •
                            ${escapeHTML(item.priority)}
                        </small>

                    </div>

                </div>

            `)
            .join("");
}


// ============================================================
// EMERGENCY
// ============================================================

async function loadEmergency() {

    const result =
        await api(
            "/emergency"
        );

    if (!result) return;

    const container =
        document.getElementById(
            "emergency-list"
        ) ||
        document.getElementById(
            "emergency-grid"
        );

    if (!container) return;

    const emergency =
        Array.isArray(result.data)
            ? result.data
            : [];

    if (!emergency.length) {

        container.innerHTML = `
            <div class="empty-state">
                🚨 Emergency information unavailable.
            </div>
        `;

        return;
    }

    container.innerHTML =
        emergency
            .map(item => `

                <div class="emergency-card">

                    <div class="emergency-icon">
                        🚨
                    </div>

                    <div>

                        <h3>
                            ${escapeHTML(
                                item.service
                            )}
                        </h3>

                        <p>
                            ${escapeHTML(
                                item.description || ""
                            )}
                        </p>

                        <strong>
                            📞 ${escapeHTML(
                                item.contact
                            )}
                        </strong>

                    </div>

                </div>

            `)
            .join("");
}


// ============================================================
// THEME
// ============================================================

function toggleTheme() {

    document.body.classList.toggle(
        "dark-mode"
    );

    const dark =
        document.body.classList.contains(
            "dark-mode"
        );

    localStorage.setItem(
        "campus-theme",
        dark
            ? "dark"
            : "light"
    );

    updateThemeButtons();
}


function loadTheme() {

    if (
        localStorage.getItem(
            "campus-theme"
        ) === "dark"
    ) {

        document.body.classList.add(
            "dark-mode"
        );
    }

    updateThemeButtons();
}


function updateThemeButtons() {

    const dark =
        document.body.classList.contains(
            "dark-mode"
        );

    setText(
        "theme-icon",
        dark
            ? "☀️"
            : "🌙"
    );

    setText(
        "theme-text",
        dark
            ? "Light Mode"
            : "Dark Mode"
    );

    document
        .querySelectorAll(
            "[data-theme-toggle]"
        )
        .forEach(
            button =>
                button.textContent =
                    dark
                        ? "☀️"
                        : "🌙"
        );
}


// ============================================================
// MOBILE
// ============================================================

function toggleMobileNav() {

    const sidebar =
        document.querySelector(
            ".sidebar"
        );

    if (!sidebar) return;

    sidebar.classList.toggle(
        "mobile-open"
    );
}


// ============================================================
// TOAST
// ============================================================

function showToast(
    message,
    type = "info"
) {

    let container =
        document.getElementById(
            "toast-container"
        );

    if (!container) {

        container =
            document.createElement(
                "div"
            );

        container.id =
            "toast-container";

        container.className =
            "toast-container";

        document.body.appendChild(
            container
        );
    }

    const toast =
        document.createElement(
            "div"
        );

    toast.className =
        `toast toast-${type}`;

    toast.textContent =
        message;

    container.appendChild(
        toast
    );

    setTimeout(() => {

        toast.classList.add(
            "hide"
        );

        setTimeout(
            () =>
                toast.remove(),
            300
        );

    }, 3000);
}


// ============================================================
// HELPERS
// ============================================================

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );

    if (element) {
        element.textContent =
            value;
    }
}


function getValue(
    id
) {

    const element =
        document.getElementById(
            id
        );

    return element
        ? element.value
        : "";
}


function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}


function escapeAttribute(
    value
) {

    return String(
        value ?? ""
    )
        .replace(
            /\\/g,
            "\\\\"
        )
        .replace(
            /'/g,
            "\\'"
        )
        .replace(
            /"/g,
            "&quot;"
        );
}


function formatDate(
    dateString
) {

    if (!dateString) return "";

    const date =
        new Date(
            dateString
        );

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {
        return dateString;
    }

    return date.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );
}


// ============================================================
// GLOBAL FUNCTIONS
// ============================================================

window.showPage =
    showPage;

window.askAI =
    askAI;

window.sendAIMessage =
    sendAIMessage;

window.handleAIKey =
    handleAIKey;

window.toggleTheme =
    toggleTheme;

window.toggleMobileNav =
    toggleMobileNav;

window.searchClassrooms =
    searchClassrooms;

window.performGlobalSearch =
    performGlobalSearch;

window.globalSearch =
    globalSearch;

window.findLocation =
    findLocation;

window.submitComplaint =
    submitComplaint;

window.openLocation =
    openLocation;

window.mapLocation =
    mapLocation;

window.handleSearchResult =
    handleSearchResult;

window.loadAnnouncements =
    loadAnnouncements;

window.initCampusMap =
    initCampusMap;

window.refreshGoogleMap =
    refreshGoogleMap;

window.focusMapOnPIET =
    focusMapOnPIET;


// ============================================================
// FOOD GLOBAL FUNCTIONS
// ============================================================

window.openFoodDetails =
    openFoodDetails;

window.closeFoodDetails =
    closeFoodDetails;

window.showFoodOnMap =
    showFoodOnMap;

window.focusFoodLocation =
    focusFoodLocation;


// ============================================================
// LIBRARY GLOBAL FUNCTIONS
// ============================================================

window.loadLibraryAvailability =
    loadLibraryAvailability;

window.openLibraryFloor =
    openLibraryFloor;

window.closeLibraryFloor =
    closeLibraryFloor;

window.renderLibrary =
    renderLibrary;


// ============================================================
// EVENT GLOBAL FUNCTIONS
// ============================================================

window.openEventDetails =
    openEventDetails;

window.closeEventDetails =
    closeEventDetails;

window.renderEvents =
    renderEvents;


// ============================================================
// KEYBOARD ESCAPE FOR MODALS
// ============================================================

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key !== "Escape"
        ) {
            return;
        }

        closeFoodDetails();

        closeLibraryFloor();

        closeEventDetails();

    }
);


// ============================================================
// FRONTEND READY
// ============================================================

console.log(
    "🤖 Campus Helper frontend ready!"
);

console.log(
    "🛰️ Live Google Maps Satellite integration ready!"
);

console.log(
    "📍 Enhanced location search with zoom, address and marker animation ready!"
);

console.log(
    "🍔 Food & Canteen details integration ready!"
);

console.log(
    "📚 Library floor availability integration ready!"
);

console.log(
    "📅 Event details integration ready!"
);

console.log(
    "📍 Default map location: Poornima Institute of Engineering & Technology"
);